/**
 * 考点阅读器 - 文件树同步模块
 *
 * 作为 interconnModule 注册到连接管理器，tag="tree"
 * 负责文件树的同步、文件夹创建/删除等操作
 *
 * 消息协议（tag="tree"）：
 * 接收方向（action 字段路由）：
 *   - getTree: 请求文件树 { }
 *   - createFolder: 创建文件夹 { name, parentId }
 *   - deleteNode: 删除节点 { nodeId }
 *
 * 发送方向（response 字段）：
 *   - treeData: 文件树数据 { tree: [...] }
 *   - folderCreated: 文件夹创建结果 { folderId, success, error }
 *   - nodeDeleted: 节点删除结果 { success, error }
 *   - treeUpdated: 文件树已更新（通知手机端刷新）
 */
import { interconnModule } from './interconn.js';
import dataManager from './dataManager.js';

export default class interconnTree {
    static "__interconnModule__" = true;
    static name = 'tree';

    constructor({ addListener, send, setEventListener }) {
        this.send = send;

        const onmessage = async (data) => {
            const { action, ...payload } = data;
            try {
                switch (action) {
                    case 'getTree':
                        await this.handleGetTree();
                        break;
                    case 'createFolder':
                        await this.handleCreateFolder(payload);
                        break;
                    case 'deleteNode':
                        await this.handleDeleteNode(payload);
                        break;
                    default:
                        console.warn('[BT-Tree] Unknown action: ' + action);
                }
            } catch (e) {
                console.error('[BT-Tree] Error: ' + e.message);
            }
        };

        addListener(onmessage);

        // When connection opens or reconnects, auto-send tree
        setEventListener((event) => {
            if (event === 'open') {
                // Auto-push tree on connection
                setTimeout(() => this.handleGetTree(), 500);
            }
        });
    }

    /**
     * 处理获取文件树请求
     */
    async handleGetTree() {
        console.log('[BT-Tree] getTree request');
        const tree = await dataManager.getFolderTreeForBluetooth();
        await this.send({
            response: 'treeData',
            tree: tree
        });
        console.log('[BT-Tree] Tree sent (' + tree.length + ' top-level nodes)');
    }

    /**
     * 处理创建文件夹请求
     */
    async handleCreateFolder({ name, parentId }) {
        console.log('[BT-Tree] createFolder: ' + name + ' parentId=' + (parentId || 'bt_root'));
        try {
            const folderId = await dataManager.createBluetoothFolder(name, parentId);
            await this.send({
                response: 'folderCreated',
                folderId: folderId,
                success: true
            });
            // Notify phone to refresh tree
            await this.handleGetTree();
        } catch (e) {
            await this.send({
                response: 'folderCreated',
                folderId: null,
                success: false,
                error: e.message
            });
        }
    }

    /**
     * 处理删除节点请求
     */
    async handleDeleteNode({ nodeId }) {
        console.log('[BT-Tree] deleteNode: ' + nodeId);
        try {
            await dataManager.deleteBluetoothNode(nodeId);
            await this.send({
                response: 'nodeDeleted',
                success: true
            });
            // Notify phone to refresh tree
            await this.handleGetTree();
        } catch (e) {
            await this.send({
                response: 'nodeDeleted',
                success: false,
                error: e.message
            });
        }
    }
}
