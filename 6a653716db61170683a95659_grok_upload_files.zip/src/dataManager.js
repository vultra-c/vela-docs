/**
 * 考点阅读器 - 数据管理器
 * 处理知识点树导航、分页、删除等功能
 */
import { knowledgeTree } from './knowledgeData.js'
import { builtinExamples } from './builtinData.js'
import { parseContent, isSubjectSpecific, formatForDisplay } from './subjectParser.js'
import storage from '@system.storage'

const STORAGE_KEY_DELETED = 'KD_DATA_DELETED'
const STORAGE_KEY_INIT = 'KD_DATA_INIT'
const STORAGE_KEY_BT_CONTENT = 'KD_BT_CONTENT'  // 蓝牙传输内容存储键

// 分页参数（手环屏幕336×480）
// 滚动区域：480px，内边距10px×2 = 460px 可用高度
// 默认行高30px → 最多15行
// 文字宽296px ÷ 26px ≈ 11字/行
// 文字铺满全屏，遮罩栏为半透明叠加层
const MAX_LINES_PER_PAGE = 15
const CHARS_PER_LINE = 11

// ---------------------------------------------------------------------------
// Pre-computed cache for built-in example pages.
// Built-in examples never change, so their formatted + paginated content is
// computed once at module load time instead of on every access.
// ---------------------------------------------------------------------------
const _builtinPagesCache = {}
const _builtinNameCache = {}
const _builtinFormattedCache = {}

function _precomputeBuiltinExamples() {
  for (let i = 0; i < builtinExamples.length; i++) {
    const item = builtinExamples[i]
    _builtinNameCache[item.id] = item.name
    let formatted = item.content
    if (isSubjectSpecific(item.content)) {
      const parsed = parseContent(item.content)
      formatted = formatForDisplay(parsed)
    }
    _builtinFormattedCache[item.id] = formatted
    _builtinPagesCache[item.id] = splitContentIntoPages(formatted)
  }
}

// ---------------------------------------------------------------------------
// getDeletedSet: read the deleted-ID set from storage once, then cache it
// in memory to avoid repeated storage reads on every list / search call.
// ---------------------------------------------------------------------------
let _deletedSetCache = null

// 获取已删除内容的ID集合（memory-cached after first read）
function getDeletedSet() {
  if (_deletedSetCache) {
    return Promise.resolve(_deletedSetCache)
  }
  return new Promise((resolve) => {
    storage.get({
      key: STORAGE_KEY_DELETED,
      success: (data) => {
        let result
        if (data) {
          try {
            result = new Set(JSON.parse(data))
          } catch (e) {
            result = new Set()
          }
        } else {
          result = new Set()
        }
        _deletedSetCache = result
        resolve(result)
      },
      fail: () => {
        _deletedSetCache = new Set()
        resolve(_deletedSetCache)
      }
    })
  })
}

// 保存已删除内容ID集合（updates cache）
function saveDeletedSet(deletedSet) {
  _deletedSetCache = deletedSet
  return new Promise((resolve) => {
    storage.set({
      key: STORAGE_KEY_DELETED,
      value: JSON.stringify(Array.from(deletedSet)),
      success: () => resolve(true),
      fail: () => resolve(false)
    })
  })
}

// ==================== 蓝牙传输内容存储 ====================

// Memory cache for bluetooth content to avoid repeated storage reads.
let _btContentCache = null

// 获取所有蓝牙传输内容（memory-cached after first read）
function getBluetoothContent() {
  if (_btContentCache) {
    return Promise.resolve(_btContentCache)
  }
  return new Promise((resolve) => {
    storage.get({
      key: STORAGE_KEY_BT_CONTENT,
      success: (data) => {
        let result
        if (data) {
          try {
            result = JSON.parse(data)
          } catch (e) {
            result = []
          }
        } else {
          result = []
        }
        _btContentCache = result
        resolve(result)
      },
      fail: () => {
        _btContentCache = []
        resolve(_btContentCache)
      }
    })
  })
}

// 保存蓝牙传输内容列表（updates cache）
function saveBluetoothContentList(list) {
  _btContentCache = list
  return new Promise((resolve) => {
    storage.set({
      key: STORAGE_KEY_BT_CONTENT,
      value: JSON.stringify(list),
      success: () => resolve(true),
      fail: () => resolve(false)
    })
  })
}

// 在 knowledgeTree 中根据 ID 查找节点
function findNodeById(node, id) {
  if (node.id === id) return node
  if (node.children) {
    for (let i = 0; i < node.children.length; i++) {
      const found = findNodeById(node.children[i], id)
      if (found) return found
    }
  }
  return null
}

function findFolderById(id) {
  for (let i = 0; i < knowledgeTree.length; i++) {
    const node = findNodeById(knowledgeTree[i], id)
    if (node) return node
  }
  return null
}

// 根据路径数组获取节点
function getNodeByPath(path) {
  if (!path || path.length === 0) return null
  let node = knowledgeTree
  for (let i = 0; i < path.length; i++) {
    const idx = path[i]
    if (i === 0) {
      node = knowledgeTree[idx]
    } else {
      if (node && node.children && node.children[idx]) {
        node = node.children[idx]
      } else {
        return null
      }
    }
  }
  return node
}

// 根据路径字符串获取节点
function getNodeByPathStr(pathStr) {
  if (!pathStr) return null
  const path = pathStr.split(',').map(s => parseInt(s))
  return getNodeByPath(path)
}

// 获取某路径下文件夹的可见子项（过滤已删除的）
function getVisibleChildren(pathStr) {
  return new Promise((resolve) => {
    const node = getNodeByPathStr(pathStr)
    if (!node || node.type !== 'folder' || !node.children) {
      resolve([])
      return
    }
    getDeletedSet().then((deletedSet) => {
      const visible = node.children.filter(child => !deletedSet.has(child.id))
      resolve(visible)
    })
  })
}

// 分页内容：按行数切分，确保文字铺满全屏
// 超长行自动折行，每行最多 CHARS_PER_LINE 个字符
function splitContentIntoPages(content) {
  if (!content) return ['无内容']
  const pages = []
  let current = ''
  let lineCount = 0
  const lines = content.split('\n')

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]

    // 处理空行：空行占一行
    if (line.length === 0) {
      if (lineCount >= MAX_LINES_PER_PAGE && current.length > 0) {
        pages.push(current)
        current = ''
        lineCount = 0
      }
      current += '\n'
      lineCount++
      continue
    }

    // 将超长行拆分为多行（每行最多 CHARS_PER_LINE 字符）
    let remaining = line
    const subLines = []
    while (remaining.length > CHARS_PER_LINE) {
      subLines.push(remaining.substring(0, CHARS_PER_LINE))
      remaining = remaining.substring(CHARS_PER_LINE)
    }
    subLines.push(remaining)

    // 逐行添加，控制每页行数
    for (let j = 0; j < subLines.length; j++) {
      if (lineCount >= MAX_LINES_PER_PAGE && current.length > 0) {
        pages.push(current)
        current = ''
        lineCount = 0
      }
      current += subLines[j] + '\n'
      lineCount++
    }
  }
  if (current.length > 0) {
    pages.push(current)
  }
  return pages.length > 0 ? pages : ['无内容']
}

// Pre-compute built-in example pages and names at module load time.
// This runs once when the module is first imported and caches the results
// so that subsequent reader / search calls return instantly.
_precomputeBuiltinExamples()

export default {
  /**
   * 初始化数据
   */
  initData() {
    storage.get({
      key: STORAGE_KEY_INIT,
      success: (data) => {
        if (!data) {
          storage.set({ key: STORAGE_KEY_INIT, value: 'true' })
          storage.set({ key: STORAGE_KEY_DELETED, value: '[]' })
        }
      },
      fail: () => {
        storage.set({ key: STORAGE_KEY_INIT, value: 'true' })
        storage.set({ key: STORAGE_KEY_DELETED, value: '[]' })
      }
    })
  },

  /**
   * 获取主页列表项
   * 主页直接显示根级文件夹和文件，无"蓝牙传输"包装层
   */
  getTopLevelFolders() {
    return new Promise((resolve) => {
      getBluetoothContent().then((btList) => {
        if (!btList) btList = []
        // 返回根级文件夹和文件
        const items = btList
          .filter(item =>
            (item.type === 'content' && (item.folder === 'bt_root' || !item.folder)) ||
            (item.type === 'folder' && (item.parentId === 'bt_root' || !item.parentId))
          )
          .map(item => ({
            id: item.id,
            name: item.name,
            type: item.type || 'content'
          }))
        resolve(items)
      })
    })
  },

  /**
   * 获取某路径下可见子项
   * 支持 "bt" 路径和 "bt_folder_*" 路径（蓝牙传输子文件夹）
   */
  getVisibleChildren(pathStr) {
    return new Promise((resolve) => {
      // 蓝牙传输根目录
      if (pathStr === 'bt') {
        getBluetoothContent().then((btList) => {
          // 返回根级文件夹和文件（folder === 'bt_root'）
          const items = btList
            .filter(item => (item.folder === 'bt_root' || (item.type === 'folder' && item.parentId === 'bt_root')))
            .map(item => ({
              id: item.id,
              name: item.name,
              type: item.type || 'content'
            }))
          resolve(items)
        })
        return
      }

      // 蓝牙传输子文件夹（bt_folder_* 路径）
      if (pathStr && pathStr.startsWith('bt_folder_')) {
        getBluetoothContent().then((btList) => {
          // 返回该文件夹下的子文件夹和文件
          const items = btList
            .filter(item => item.folder === pathStr || (item.type === 'folder' && item.parentId === pathStr))
            .map(item => ({
              id: item.id,
              name: item.name,
              type: item.type || 'content'
            }))
          resolve(items)
        })
        return
      }

      // 内置示例文件夹
      if (pathStr === 'builtin') {
        const items = builtinExamples.map(item => ({
          id: item.id,
          name: item.name,
          type: 'content',
          content: item.content
        }))
        resolve(items)
        return
      }

      // 内置文件夹
      const node = getNodeByPathStr(pathStr)
      if (!node || node.type !== 'folder' || !node.children) {
        resolve([])
        return
      }
      getDeletedSet().then((deletedSet) => {
        const visible = node.children.filter(child => !deletedSet.has(child.id))
        resolve(visible)
      })
    })
  },

  /**
   * 根据路径字符串获取节点
   */
  getNodeByPathStr,

  /**
   * 获取节点名称
   * 支持 "bt" 路径和 "bt_folder_*" 路径（蓝牙传输子文件夹）
   */
  getNodeName(pathStr) {
    if (pathStr === 'builtin') return '内置示例'
    // 蓝牙传输子文件夹
    if (pathStr && pathStr.startsWith('bt_folder_')) {
      // 从缓存中查找文件夹名称（同步访问）
      if (_btContentCache) {
        const folder = _btContentCache.find(item => item.id === pathStr)
        if (folder) return folder.name
      }
      return '文件夹'
    }
    const node = getNodeByPathStr(pathStr)
    return node ? node.name : ''
  },

  /**
   * 获取内容节点的分页内容
   * 支持 bt_ 前缀的蓝牙传输内容
   */
  getReaderPages(pathStr) {
    return new Promise((resolve) => {
      // 蓝牙传输内容：ID 以 bt_ 开头
      if (pathStr && pathStr.startsWith('bt_')) {
        getBluetoothContent().then((btList) => {
          const item = btList.find(item => item.id === pathStr)
          if (item) {
            resolve(splitContentIntoPages(item.content))
          } else {
            resolve(['内容不存在'])
          }
        })
        return
      }

      // 内置内容
      const node = getNodeByPathStr(pathStr)
      if (!node || node.type !== 'content') {
        resolve(['无内容'])
        return
      }
      getDeletedSet().then((deletedSet) => {
        if (deletedSet.has(node.id)) {
          resolve(['该内容已被删除'])
          return
        }
        resolve(splitContentIntoPages(node.content))
      })
    })
  },

  /**
   * 删除单个考点内容
   * 支持 bt_ 前缀的蓝牙传输内容
   */
  deleteContent(pathStr) {
    return new Promise((resolve) => {
      // Built-in examples cannot be deleted
      if (pathStr && pathStr.startsWith('builtin_')) {
        resolve(false)
        return
      }

      // 蓝牙传输内容
      if (pathStr && pathStr.startsWith('bt_')) {
        getBluetoothContent().then((btList) => {
          const filtered = btList.filter(item => item.id !== pathStr)
          saveBluetoothContentList(filtered).then(() => resolve(true))
        })
        return
      }

      // 内置内容
      const node = getNodeByPathStr(pathStr)
      if (!node) {
        resolve(false)
        return
      }
      getDeletedSet().then((deletedSet) => {
        deletedSet.add(node.id)
        saveDeletedSet(deletedSet).then(() => resolve(true))
      })
    })
  },

  /**
   * 删除文件夹（将其ID加入已删除集合，同时递归删除所有子项）
   * 支持 "bt" 路径（清空所有蓝牙传输内容）和 "bt_folder_*" 路径
   */
  deleteFolder(pathStr) {
    return new Promise((resolve) => {
      // 蓝牙传输根目录：清空所有蓝牙内容
      if (pathStr === 'bt') {
        saveBluetoothContentList([]).then(() => resolve(true))
        return
      }

      // 蓝牙传输子文件夹：递归删除该文件夹及其子项
      if (pathStr && pathStr.startsWith('bt_folder_')) {
        this.deleteBluetoothNode(pathStr).then(() => resolve(true))
        return
      }

      // 内置示例文件夹：不允许删除
      if (pathStr === 'builtin') {
        resolve(false)
        return
      }

      // 内置文件夹
      const node = getNodeByPathStr(pathStr)
      if (!node) {
        resolve(false)
        return
      }
      getDeletedSet().then((deletedSet) => {
        // 递归收集文件夹下所有节点的ID
        function collectIds(n) {
          deletedSet.add(n.id)
          if (n.children) {
            n.children.forEach(child => collectIds(child))
          }
        }
        collectIds(node)
        saveDeletedSet(deletedSet).then(() => resolve(true))
      })
    })
  },

  /**
   * 删除所有考点（包括蓝牙传输内容）
   */
  deleteAll() {
    return new Promise((resolve) => {
      const allIds = []
      function collect(node) {
        if (node.type === 'content') {
          allIds.push(node.id)
        } else if (node.type === 'folder' && node.children) {
          node.children.forEach(child => collect(child))
        }
      }
      knowledgeTree.forEach(node => collect(node))

      getDeletedSet().then((deletedSet) => {
        allIds.forEach(id => deletedSet.add(id))
        saveDeletedSet(deletedSet).then(() => {
          // 同时清空蓝牙传输内容
          saveBluetoothContentList([]).then(() => resolve(true))
        })
      })
    })
  },

  /**
   * 统计所有考点数量（包括蓝牙传输内容）
   */
  getTotalContentCount() {
    return new Promise((resolve) => {
      getDeletedSet().then((deletedSet) => {
        let count = 0
        function countNodes(node) {
          if (node.type === 'content' && !deletedSet.has(node.id)) {
            count++
          } else if (node.type === 'folder' && node.children) {
            node.children.forEach(child => countNodes(child))
          }
        }
        knowledgeTree.forEach(node => countNodes(node))

        // 加上蓝牙传输内容数量
        getBluetoothContent().then((btList) => {
          count += btList ? btList.length : 0
          resolve(count)
        })
      })
    })
  },

  /**
   * 获取考点占用的存储大小（字节，包括蓝牙传输内容）
   */
  getContentStorageSize() {
    return new Promise((resolve) => {
      getDeletedSet().then((deletedSet) => {
        let size = 0
        function calcSize(node) {
          if (node.type === 'content' && !deletedSet.has(node.id)) {
            size += (node.content || '').length
            size += (node.name || '').length
          } else if (node.type === 'folder' && node.children) {
            node.children.forEach(child => calcSize(child))
          }
        }
        knowledgeTree.forEach(node => calcSize(node))

        // 加上蓝牙传输内容大小
        getBluetoothContent().then((btList) => {
          if (btList) {
            btList.forEach(item => {
              size += (item.content || '').length
              size += (item.name || '').length
            })
          }
          resolve(size)
        })
      })
    })
  },

  /**
   * 格式化文件大小
   */
  formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  },

  /**
   * 获取每页行数
   */
  getCharsPerPage() {
    return MAX_LINES_PER_PAGE * CHARS_PER_LINE
  },

  /**
   * 获取分页参数
   */
  getPaginationInfo() {
    return {
      maxLines: MAX_LINES_PER_PAGE,
      charsPerLine: CHARS_PER_LINE
    }
  },

  // ==================== 蓝牙传输功能 ====================

  /**
   * 保存蓝牙传输的 txt 内容
   * @param {string} filename 文件名（不含后缀）
   * @param {string} content  正文内容
   * @param {string} targetFolder 目标文件夹 ID（'bt_root' 表示根目录，'bt_folder_xxx' 表示子文件夹）
   */
  saveBluetoothContent(filename, content, targetFolder) {
    return new Promise((resolve) => {
      getBluetoothContent().then((btList) => {
        const id = 'bt_' + Date.now()
        const item = {
          id: id,
          name: filename,
          type: 'content',
          content: content,
          folder: targetFolder || 'bt_root',
          created: Date.now()
        }
        btList.push(item)
        saveBluetoothContentList(btList).then(() => {
          console.log('[DM] Bluetooth content saved: ' + filename + ' (' + content.length + ' chars) folder=' + (targetFolder || 'bt_root'))
          resolve(id)
        })
      })
    })
  },

  /**
   * 创建蓝牙传输文件夹
   * @param {string} name 文件夹名称
   * @param {string} parentId 父文件夹 ID（'bt_root' 表示根目录）
   * @returns {Promise<string>} 新文件夹 ID
   */
  createBluetoothFolder(name, parentId) {
    return new Promise((resolve) => {
      getBluetoothContent().then((btList) => {
        const id = 'bt_folder_' + Date.now()
        const folder = {
          id: id,
          name: name,
          type: 'folder',
          parentId: parentId || 'bt_root',
          created: Date.now()
        }
        btList.push(folder)
        saveBluetoothContentList(btList).then(() => {
          console.log('[DM] Folder created: ' + name + ' parentId=' + (parentId || 'bt_root'))
          resolve(id)
        })
      })
    })
  },

  /**
   * 删除蓝牙传输节点（文件或文件夹）
   * 如果是文件夹，递归删除其下所有子项
   * @param {string} nodeId 节点 ID
   */
  deleteBluetoothNode(nodeId) {
    return new Promise((resolve) => {
      getBluetoothContent().then((btList) => {
        // 收集要删除的 ID
        const toDelete = new Set([nodeId])

        // 递归收集子文件夹和文件
        let changed = true
        while (changed) {
          changed = false
          btList.forEach(item => {
            if (item.folder && toDelete.has(item.folder) && !toDelete.has(item.id)) {
              toDelete.add(item.id)
              changed = true
            }
            if (item.parentId && toDelete.has(item.parentId) && !toDelete.has(item.id)) {
              toDelete.add(item.id)
              changed = true
            }
          })
        }

        const filtered = btList.filter(item => !toDelete.has(item.id))
        saveBluetoothContentList(filtered).then(() => {
          console.log('[DM] Deleted node: ' + nodeId + ' (total removed: ' + toDelete.size + ')')
          resolve(true)
        })
      })
    })
  },

  /**
   * 获取文件夹树（供手机端请求使用）
   * 返回根级文件夹和文件的树结构，不包含正文内容
   * 不再有"蓝牙传输"包装层，主页即为根目录
   */
  getFolderTreeForBluetooth() {
    return new Promise((resolve) => {
      getBluetoothContent().then((btList) => {
        if (!btList) btList = []

        // 分离文件夹和文件
        const folders = btList.filter(item => item.type === 'folder')
        const files = btList.filter(item => item.type === 'content')

        // 递归构建蓝牙文件夹树
        function buildBtNode(node) {
          const result = {
            id: node.id,
            name: node.name,
            type: node.type
          }
          if (node.type === 'folder') {
            result.children = []
            // 添加子文件夹
            folders.filter(f => f.parentId === node.id).forEach(f => {
              const child = buildBtNode(f)
              result.children.push(child)
            })
            // 添加文件
            files.filter(f => f.folder === node.id).forEach(f => {
              result.children.push({
                id: f.id,
                name: f.name,
                type: 'content'
              })
            })
          }
          return result
        }

        // Build tree from root level — no "蓝牙传输" wrapper
        const tree = []
        // 根级文件夹
        folders.filter(f => f.parentId === 'bt_root' || !f.parentId).forEach(f => {
          tree.push(buildBtNode(f))
        })
        // 根级文件
        files.filter(f => f.folder === 'bt_root' || !f.folder).forEach(f => {
          tree.push({
            id: f.id,
            name: f.name,
            type: 'content'
          })
        })

        resolve(tree)
      })
    })
  },

  /**
   * 获取蓝牙传输内容列表（用于显示）
   */
  getBluetoothContentList() {
    return getBluetoothContent()
  },

  /**
   * 删除指定蓝牙传输内容
   */
  deleteBluetoothContent(id) {
    return new Promise((resolve) => {
      getBluetoothContent().then((btList) => {
        const filtered = btList.filter(item => item.id !== id)
        saveBluetoothContentList(filtered).then(() => resolve(true))
      })
    })
  },

  /**
   * 获取蓝牙传输内容数量
   */
  getBluetoothContentCount() {
    return new Promise((resolve) => {
      getBluetoothContent().then((btList) => {
        resolve(btList ? btList.length : 0)
      })
    })
  },

  // ==================== Built-in Examples ====================

  /**
   * Get built-in example data entries
   */
  getBuiltinExamples() {
    return builtinExamples
  },

  /**
   * Get reader pages for a built-in example
   */
  getBuiltinReaderPages(id) {
    // Return pre-computed pages from cache (computed at module load)
    if (_builtinPagesCache[id]) {
      return _builtinPagesCache[id]
    }
    // Fallback: compute on demand (should not normally happen)
    const item = builtinExamples.find(e => e.id === id)
    if (item) {
      if (isSubjectSpecific(item.content)) {
        const parsed = parseContent(item.content)
        const formatted = formatForDisplay(parsed)
        const pages = splitContentIntoPages(formatted)
        _builtinPagesCache[id] = pages
        return pages
      }
      const pages = splitContentIntoPages(item.content)
      _builtinPagesCache[id] = pages
      return pages
    }
    return ['内容不存在']
  },

  /**
   * Get built-in example name by id
   */
  getBuiltinName(id) {
    if (_builtinNameCache[id]) {
      return _builtinNameCache[id]
    }
    const item = builtinExamples.find(e => e.id === id)
    return item ? item.name : ''
  },

  // ==================== Search ====================

  /**
   * Search all content (built-in tree + bluetooth + builtin examples)
   * @param {string} keyword - search keyword
   * @returns {Promise<Array>} array of {name, path, snippet, type}
   */
  searchContent(keyword) {
    return new Promise((resolve) => {
      if (!keyword || keyword.trim().length === 0) {
        resolve([])
        return
      }
      const kw = keyword.trim().toLowerCase()
      const results = []

      // Search built-in knowledge tree
      getDeletedSet().then((deletedSet) => {
        function searchTree(node, path) {
          if (deletedSet.has(node.id)) return
          if (node.type === 'content') {
            const content = (node.content || '').toLowerCase()
            const name = (node.name || '').toLowerCase()
            if (content.includes(kw) || name.includes(kw)) {
              const idx = content.indexOf(kw)
              let snippet = ''
              if (idx >= 0) {
                const start = Math.max(0, idx - 10)
                const end = Math.min(content.length, idx + kw.length + 20)
                snippet = (start > 0 ? '...' : '') + content.substring(start, end) + (end < content.length ? '...' : '')
              }
              results.push({
                name: node.name,
                path: path,
                snippet: snippet,
                type: 'builtin'
              })
            }
          } else if (node.type === 'folder' && node.children) {
            for (let i = 0; i < node.children.length; i++) {
              searchTree(node.children[i], path + ',' + i)
            }
          }
        }
        knowledgeTree.forEach((node, i) => searchTree(node, String(i)))

        // Search bluetooth content
        getBluetoothContent().then((btList) => {
          if (btList) {
            btList.forEach(item => {
              const content = (item.content || '').toLowerCase()
              const name = (item.name || '').toLowerCase()
              if (content.includes(kw) || name.includes(kw)) {
                const idx = content.indexOf(kw)
                let snippet = ''
                if (idx >= 0) {
                  const start = Math.max(0, idx - 10)
                  const end = Math.min(content.length, idx + kw.length + 20)
                  snippet = (start > 0 ? '...' : '') + content.substring(start, end) + (end < content.length ? '...' : '')
                }
                results.push({
                  name: item.name,
                  path: item.id,
                  snippet: snippet,
                  type: 'bluetooth'
                })
              }
            })
          }

          // Search built-in examples (use pre-computed formatted content
          // so the snippet matches what the user sees in the reader)
          builtinExamples.forEach(item => {
            const formatted = _builtinFormattedCache[item.id] || item.content
            const content = formatted.toLowerCase()
            const name = (item.name || '').toLowerCase()
            if (content.includes(kw) || name.includes(kw)) {
              const idx = content.indexOf(kw)
              let snippet = ''
              if (idx >= 0) {
                const start = Math.max(0, idx - 10)
                const end = Math.min(content.length, idx + kw.length + 20)
                snippet = (start > 0 ? '...' : '') + content.substring(start, end) + (end < content.length ? '...' : '')
              }
              results.push({
                name: item.name,
                path: item.id,
                snippet: snippet,
                type: 'example'
              })
            }
          })

          resolve(results)
        })
      })
    })
  },

  /**
   * Get reader pages by path (supports builtin_ prefix for examples)
   */
  getReaderPagesUnified(pathStr) {
    return new Promise((resolve) => {
      // Built-in examples
      if (pathStr && pathStr.startsWith('builtin_')) {
        resolve(this.getBuiltinReaderPages(pathStr))
        return
      }
      // Bluetooth content
      if (pathStr && pathStr.startsWith('bt_')) {
        this.getReaderPages(pathStr).then(resolve)
        return
      }
      // Built-in knowledge tree
      this.getReaderPages(pathStr).then(resolve)
    })
  },

  /**
   * Get node name by path (supports builtin_ prefix)
   */
  getUnifiedNodeName(pathStr) {
    if (pathStr && pathStr.startsWith('builtin_')) {
      return this.getBuiltinName(pathStr)
    }
    return this.getNodeName(pathStr)
  }
}
