/**
 * device-adapt.js (v4.0)
 * 多设备屏幕适配工具
 * 支持：小米手环9 Pro (336x480), 小米手环10 (192x490), 小米手表等
 */
import device from '@system.device'

var _deviceInfo = null
var _initialized = false

function initDeviceInfo() {
  if (_initialized) return Promise.resolve(_deviceInfo)
  return new Promise(function (resolve) {
    device.getInfo({
      success: function (data) {
        _deviceInfo = data
        _initialized = true
        resolve(data)
      },
      fail: function () {
        _deviceInfo = { width: 336, height: 480 }
        _initialized = true
        resolve(_deviceInfo)
      }
    })
  })
}

function getDeviceInfo() {
  return _deviceInfo
}

function isRoundScreen() {
  if (!_deviceInfo) return false
  var w = _deviceInfo.width || 336
  var h = _deviceInfo.height || 480
  // 圆形屏幕宽高比接近 1:1
  return Math.abs(w - h) < 20
}

function getTopBarHeight() {
  if (!_deviceInfo) return 44
  var h = _deviceInfo.height || 480
  if (h <= 200) return 30
  if (h <= 400) return 36
  return 44
}

function getContentPadding() {
  if (!_deviceInfo) return 12
  var w = _deviceInfo.width || 336
  if (w <= 200) return 8
  return 12
}

function getDefaultFontSize() {
  if (!_deviceInfo) return 28
  var w = _deviceInfo.width || 336
  if (w <= 200) return 20
  return 28
}

function getListFontSize() {
  if (!_deviceInfo) return 16
  var w = _deviceInfo.width || 336
  if (w <= 200) return 13
  return 16
}

function getButtonSize() {
  if (!_deviceInfo) return 36
  var w = _deviceInfo.width || 336
  if (w <= 200) return 28
  return 36
}

export default {
  initDeviceInfo: initDeviceInfo,
  getDeviceInfo: getDeviceInfo,
  isRoundScreen: isRoundScreen,
  getTopBarHeight: getTopBarHeight,
  getContentPadding: getContentPadding,
  getDefaultFontSize: getDefaultFontSize,
  getListFontSize: getListFontSize,
  getButtonSize: getButtonSize
}
