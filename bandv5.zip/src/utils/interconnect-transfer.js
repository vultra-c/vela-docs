/**
 * 小米 Vela interconnect 文件传输协议封装 (v4.0 优化版)
 *
 * 参考喵喵电子书 (com.bandbbs.ebook) 的实现，完整实现：
 *   1. 三步握手协议 (__hs__ tag, count 0→1→2)
 *   2. ACK 确认流控 (手表收到分片后回 next，手机才发下一片)
 *   3. 错误恢复 (序号不匹配时手表回 error + 期望序号，手机重传)
 *   4. 断点续传 (手表记录当前文件名和已接收长度，支持从中断处继续)
 *   5. 存储空间检查 (开始传输前检查剩余空间)
 *   6. GC 优化 (每 10 个分片调用一次 global.runGC)
 *   7. 文本分片传输 (无需 base64，直接 JSON 字符串传输，零编码开销)
 *
 * 协议消息格式 (JSON，均包含 tag 字段用于路由)：
 *
 * 握手 (tag: "__hs__")：
 *   {"tag":"__hs__","count":0}  手机发起
 *   {"tag":"__hs__","count":1}  手表响应
 *   {"tag":"__hs__","count":2}  手机确认
 *
 * 文件传输 (tag: "file")：
 *   手机→手表：
 *     {"tag":"file","stat":"startTransfer","filename":"xxx.txt","total":N,"chunkSize":5000}
 *     {"tag":"file","stat":"d","count":N,"data":"分片文本内容"}
 *     {"tag":"file","stat":"cancel"}
 *
 *   手表→手机：
 *     {"tag":"file","type":"ready","found":false,"usage":12345}
 *     {"tag":"file","type":"ready","found":true,"length":15000,"usage":12345}
 *     {"tag":"file","type":"next","message":"N success","count":N+1}
 *     {"tag":"file","type":"error","message":"package count error","count":N}
 *     {"tag":"file","type":"success","message":"transfer success","count":N+1}
 *     {"tag":"file","type":"cancel"}
 */
import interconnect from '@system.interconnect'
import storage from '@system.storage'
import file from '@system.file'

/**
 * 将字符串转换为 Uint8Array (UTF-16LE 编码)
 * 与喵喵电子书的 str2abWrite 实现一致
 * 用于 writeArrayBuffer 写入文件，确保字节长度跟踪正确
 */
function str2abWrite(str) {
  var array = new Uint16Array(str.length)
  for (var i = 0; i < str.length; i++) {
    array[i] = str.charCodeAt(i)
  }
  return new Uint8Array(array.buffer)
}

// ---- 常量 ----
var TRANSFER_DIR = 'internal://files/received/'
var STORAGE_KEY = 'received_files'
var CURRENT_FILE_KEY = '__current_file__'
var MAX_STORAGE_USAGE = 25 * 1024 * 1024 // 25MB 存储上限检查
var HANDSHAKE_TAG = '__hs__'
var FILE_TAG = 'file'
var HANDSHAKE_TIMEOUT = 3000 // 握手超时 3 秒
var GC_INTERVAL = 10 // 每 10 个分片 GC 一次

/**
 * 创建一个 interconnect 传输会话实例
 *
 * 状态机：
 *   idle      未开始
 *   waiting   等待手机连接（含握手）
 *   connected 握手完成，等待文件传输
 *   receiving 正在接收文件
 *   success   传输成功
 *   error     错误
 */
function createInterconnectTransfer() {
  var state = 'idle'
  var destroyed = false
  var conn = null

  // 握手状态
  var handshakeResolve = null
  var handshakeTimer = null
  var handshakeConnected = false

  // 协议状态
  var filename = ''
  var totalChunks = 0
  var chunkSize = 5000
  var expectedCount = 0
  var receivedCount = 0
  var currentFileUri = ''
  var isResume = false
  var resumeLength = 0

  // 对外回调
  var api = {
    onStateChange: null,
    onMeta: null,
    onChunk: null,
    onProgress: null,
    onComplete: null,
    onError: null,
    onConnect: null,
    onDisconnect: null
  }

  function setState(s) {
    if (destroyed) return
    state = s
    if (api.onStateChange) api.onStateChange(s)
  }

  function fail(msg) {
    if (destroyed) return
    cleanup()
    setState('error')
    if (api.onError) api.onError(msg)
  }

  function cleanup() {
    if (handshakeTimer) {
      clearTimeout(handshakeTimer)
      handshakeTimer = null
    }
    handshakeResolve = null
    handshakeConnected = false
    if (conn) {
      try { conn.onmessage = null } catch (e) {}
      try { conn.onopen = null } catch (e) {}
      try { conn.onclose = null } catch (e) {}
      try { conn.onerror = null } catch (e) {}
    }
    conn = null
  }

  function resetProtocol() {
    filename = ''
    totalChunks = 0
    chunkSize = 5000
    expectedCount = 0
    receivedCount = 0
    currentFileUri = ''
    isResume = false
    resumeLength = 0
    handshakeConnected = false
    handshakeResolve = null
    if (handshakeTimer) {
      clearTimeout(handshakeTimer)
      handshakeTimer = null
    }
  }

  // ---- 发送 JSON 消息到手机 ----
  function sendMessage(obj) {
    if (destroyed || !conn) return
    try {
      var data = JSON.stringify(obj)
      conn.send({
        data: data,
        success: function () {},
        fail: function (data, code) {
          // 单条发送失败不致命
        }
      })
    } catch (e) {}
  }

  // ---- 握手处理 ----
  function handleHandshake(count) {
    if (destroyed) return
    // 收到握手消息，回复递增的 count
    var newCount = count + 1
    if (newCount < 3) {
      sendMessage({ tag: HANDSHAKE_TAG, count: newCount })
    }
    // count > 0 表示对方已响应，握手进行中
    if (count > 0 && handshakeResolve) {
      handshakeConnected = true
      if (handshakeTimer) {
        clearTimeout(handshakeTimer)
        handshakeTimer = null
      }
      var resolve = handshakeResolve
      handshakeResolve = null
      resolve()
    }
  }

  function startHandshake() {
    if (destroyed || !conn) return
    handshakeConnected = false
    // 发送初始握手消息 count=0
    sendMessage({ tag: HANDSHAKE_TAG, count: 0 })
    // 设置超时
    handshakeTimer = setTimeout(function () {
      if (destroyed) return
      if (!handshakeConnected) {
        handshakeResolve = null
        fail('握手超时，请确保手机端 APP 已打开')
      }
    }, HANDSHAKE_TIMEOUT)
  }

  function waitForHandshake() {
    return new Promise(function (resolve) {
      if (handshakeConnected) {
        resolve()
        return
      }
      handshakeResolve = resolve
      startHandshake()
    })
  }

  // ---- 接收消息处理 ----
  function handleMessage(payload) {
    if (destroyed) return
    var msg = null
    try {
      if (typeof payload === 'string') {
        msg = JSON.parse(payload)
      } else if (payload && typeof payload === 'object') {
        if (payload.data && typeof payload.data === 'string') {
          msg = JSON.parse(payload.data)
        } else if (payload.tag) {
          msg = payload
        }
      }
    } catch (e) {
      return
    }
    if (!msg || typeof msg !== 'object') return

    // 按 tag 路由
    if (msg.tag === HANDSHAKE_TAG) {
      handleHandshake(msg.count || 0)
      return
    }

    if (msg.tag === FILE_TAG) {
      handleFileMessage(msg)
      return
    }
  }

  function handleFileMessage(msg) {
    if (destroyed) return
    var stat = msg.stat
    var type = msg.type

    // 手机→手表消息（stat 字段）
    if (stat === 'startTransfer') {
      handleStartTransfer(msg)
    } else if (stat === 'd') {
      handleDataChunk(msg)
    } else if (stat === 'cancel') {
      handleCancelFromPhone()
    }
    // 手表→手表不应收到 type 消息，忽略
  }

  // ---- 处理开始传输 ----
  function handleStartTransfer(msg) {
    if (destroyed) return
    var fname = sanitizeFilename(msg.filename)
    if (!fname) {
      sendMessage({ tag: FILE_TAG, type: 'error', message: 'invalid filename', count: 0 })
      return
    }
    filename = fname
    totalChunks = msg.total || 0
    chunkSize = msg.chunkSize || 5000
    expectedCount = 0
    receivedCount = 0

    currentFileUri = TRANSFER_DIR + filename

    if (api.onMeta) api.onMeta(fname, totalChunks, chunkSize)

    // 检查存储空间是否充足
    getStorageUsage(function (usage) {
      if (usage >= MAX_STORAGE_USAGE) {
        sendMessage({
          tag: FILE_TAG,
          type: 'error',
          message: 'storage full: ' + usage,
          count: 0
        })
        if (api.onError) {
          api.onError('存储空间不足，请删除部分考点后重试')
        }
        return
      }
      setState('receiving')
      // 检查是否支持续传：读取上次传输记录
      storage.get({
        key: CURRENT_FILE_KEY,
        success: function (data) {
          var found = false
          var existingLength = 0
          if (data) {
            try {
              var info = JSON.parse(data)
              if (info && info.filename === fname && info.uri === currentFileUri) {
                found = true
                existingLength = info.length || 0
              }
            } catch (e) {}
          }

          if (found && existingLength > 0) {
            // 续传：计算从哪个分片开始
            isResume = true
            resumeLength = existingLength
            expectedCount = Math.floor(existingLength / chunkSize)
            receivedCount = expectedCount
            sendMessage({
              tag: FILE_TAG,
              type: 'ready',
              found: true,
              length: existingLength,
              usage: usage
            })
          } else {
            // 新文件
            isResume = false
            resumeLength = 0
            sendMessage({
              tag: FILE_TAG,
              type: 'ready',
              found: false,
              usage: usage
            })
          }
        },
        fail: function () {
          isResume = false
          resumeLength = 0
          sendMessage({
            tag: FILE_TAG,
            type: 'ready',
            found: false,
            usage: usage
          })
        }
      })
    })
  }

  // ---- 处理数据分片 ----
  function handleDataChunk(msg) {
    if (destroyed) return
    if (state !== 'receiving') return

    var count = msg.count
    var data = msg.data || ''
    var setCount = msg.setCount

    // 如果是续传重设序号
    if (typeof setCount === 'number' && setCount >= 0) {
      expectedCount = setCount
    }

    // 序号检查
    if (count !== expectedCount) {
      // 序号不匹配，请求重传
      sendMessage({
        tag: FILE_TAG,
        type: 'error',
        message: 'package count error',
        count: expectedCount
      })
      return
    }

    // 写入分片数据 - 使用 writeArrayBuffer + UTF-16LE 编码
    // 与喵喵电子书实现一致，确保字节长度跟踪正确以支持续传
    var writeUri = currentFileUri
    var isAppend = expectedCount > 0 || isResume
    var byteLength = data.length * 2 // UTF-16LE: 2 bytes per BMP character

    file.writeArrayBuffer({
      uri: writeUri,
      buffer: str2abWrite(data),
      append: isAppend,
      success: function () {
        receivedCount = expectedCount + 1
        expectedCount = receivedCount

        // 记录续传信息（字节长度，用于 Android 端计算续传分片）
        var currentBytes = (isResume ? resumeLength : 0) + byteLength
        if (isResume) {
          resumeLength += byteLength
        }
        storage.set({
          key: CURRENT_FILE_KEY,
          value: JSON.stringify({
            filename: filename,
            uri: currentFileUri,
            length: isResume ? resumeLength : currentBytes,
            count: receivedCount
          })
        })

        // GC 优化：每 10 个分片调用一次
        if (receivedCount % GC_INTERVAL === 0) {
          try { global.runGC && global.runGC() } catch (e) {}
        }

        // 进度回调
        if (api.onProgress) {
          api.onProgress(receivedCount, totalChunks)
        }

        // 检查是否完成
        if (receivedCount >= totalChunks) {
          // 传输完成
          sendMessage({
            tag: FILE_TAG,
            type: 'success',
            message: 'transfer success',
            count: receivedCount
          })
          // 清除续传记录
          storage.delete({ key: CURRENT_FILE_KEY })
          // 记录到已接收文件列表
          saveReceivedFile(filename, isResume ? resumeLength : currentBytes, '')
          if (api.onComplete) {
            api.onComplete(filename, totalChunks, receivedCount, '')
          }
        } else {
          // 请求下一片
          sendMessage({
            tag: FILE_TAG,
            type: 'next',
            message: count + ' success',
            count: receivedCount
          })
        }
      },
      fail: function (data, code) {
        // 写入失败
        sendMessage({
          tag: FILE_TAG,
          type: 'error',
          message: 'write failed: ' + code,
          count: expectedCount
        })
        if (api.onError) {
          api.onError('文件写入失败（错误码: ' + code + '）')
        }
      }
    })
  }

  // ---- 处理手机端取消 ----
  function handleCancelFromPhone() {
    if (destroyed) return
    storage.delete({ key: CURRENT_FILE_KEY })
    sendMessage({ tag: FILE_TAG, type: 'cancel' })
    setState('idle')
  }

  // ---- 获取存储使用量 ----
  function getStorageUsage(callback) {
    try {
      file.list({
        uri: TRANSFER_DIR,
        success: function (data) {
          var usage = 0
          if (data && data.fileList) {
            for (var i = 0; i < data.fileList.length; i++) {
              usage += data.fileList[i].length || 0
            }
          }
          callback(usage)
        },
        fail: function () {
          callback(0)
        }
      })
    } catch (e) {
      callback(0)
    }
  }

  // ---- 文件名安全过滤 ----
  function sanitizeFilename(name) {
    if (typeof name !== 'string') return ''
    // 移除路径分隔符和危险字符
    var safe = name.replace(/[\/\\]/g, '').replace(/\.\./g, '').trim()
    // 限制长度
    if (safe.length > 100) safe = safe.substring(0, 100)
    return safe
  }

  // ---- 启动 ----
  api.start = function () {
    if (destroyed) return
    cleanup()
    resetProtocol()

    try {
      conn = interconnect.instance()
    } catch (e) {
      fail('获取连接实例失败：' + (e && e.message ? e.message : e))
      return
    }

    // 注册连接事件回调
    conn.onopen = function (data) {
      if (destroyed) return
      if (state === 'waiting') {
        setState('connected')
        // 连接打开后启动握手
        waitForHandshake().then(function () {
          if (destroyed) return
          if (api.onConnect) api.onConnect()
        }).catch(function () {})
      }
    }

    conn.onclose = function (data) {
      if (destroyed) return
      if (state === 'receiving' || state === 'connected' || state === 'waiting') {
        if (api.onDisconnect) api.onDisconnect()
        if (state !== 'success') {
          fail('连接已断开')
        }
      }
    }

    conn.onerror = function (data) {
      if (destroyed) return
      var code = data && data.code
      var msg = '连接错误'
      if (code === 1001) msg = '手机端 APP 未安装'
      else if (code === 1006) msg = '连接断开'
      else if (code === 1000) msg = '未知连接错误'
      fail(msg)
    }

    // 注册消息接收
    conn.onmessage = function (data) {
      if (destroyed) return
      var payload = data
      if (data && typeof data === 'object' && 'data' in data) {
        payload = data.data
      }
      handleMessage(payload)
    }

    // 同时尝试 subscribe（兼容某些固件）
    try {
      conn.subscribe({
        success: function (data) {
          if (destroyed) return
          handleMessage(data)
        },
        fail: function () {}
      })
    } catch (e) {}

    setState('waiting')

    // 检查当前连接状态
    checkConnection()
  }

  function checkConnection() {
    if (destroyed || !conn) return
    try {
      conn.getReadyState({
        success: function (data) {
          if (destroyed) return
          if (state !== 'waiting') return
          if (data && data.status === 1) {
            setState('connected')
            waitForHandshake().then(function () {
              if (destroyed) return
              if (api.onConnect) api.onConnect()
            }).catch(function () {})
          } else {
            diagnose()
          }
        },
        fail: function () {
          if (destroyed) return
          if (state === 'waiting') diagnose()
        }
      })
    } catch (e) {
      if (state === 'waiting') diagnose()
    }
  }

  function diagnose() {
    if (destroyed || !conn) return
    try {
      conn.diagnosis({
        timeout: 10000,
        success: function (data) {
          if (destroyed) return
          if (state !== 'waiting') return
          if (data && data.status === 0) {
            setState('connected')
            waitForHandshake().then(function () {
              if (destroyed) return
              if (api.onConnect) api.onConnect()
            }).catch(function () {})
          } else if (data && data.status === 204) {
            fail('连接超时，请打开手机端 APP')
          } else if (data && data.status === 1001) {
            fail('手机端 APP 未安装')
          } else {
            fail('连接失败')
          }
        },
        fail: function (data, code) {
          if (destroyed) return
          if (state === 'waiting') {
            fail('连接诊断失败')
          }
        }
      })
    } catch (e) {
      if (state === 'waiting') {
        fail('连接诊断异常')
      }
    }
  }

  // ---- 控制 ----
  api.cancel = function () {
    if (destroyed) return
    // 通知手机端取消
    sendMessage({ tag: FILE_TAG, stat: 'cancel' })
    storage.delete({ key: CURRENT_FILE_KEY })
    cleanup()
    resetProtocol()
    setState('idle')
  }

  api.retry = function () {
    if (destroyed) return
    api.start()
  }

  api.destroy = function () {
    destroyed = true
    cleanup()
  }

  api.getState = function () {
    return state
  }

  api.isHandshakeConnected = function () {
    return handshakeConnected
  }

  return api
}

/** 读取已接收文件清单 */
function getReceivedFiles(cb) {
  storage.get({
    key: STORAGE_KEY,
    success: function (data) {
      var list = []
      if (data) {
        try {
          list = JSON.parse(data)
          if (!list || !list.length) list = []
        } catch (e) {
          list = []
        }
      }
      cb(list)
    },
    fail: function () {
      cb([])
    }
  })
}

/** 记录一个已接收文件 */
function saveReceivedFile(filename, size, folder) {
  var safeFolder = (typeof folder === 'string' && folder) ? folder : ''
  var uri = TRANSFER_DIR + (safeFolder ? safeFolder + '/' : '') + filename
  getReceivedFiles(function (list) {
    var next = []
    var existed = false
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].filename === filename && list[i].folder === safeFolder) {
        existed = true
        continue
      }
      next.push(list[i])
    }
    next.unshift({
      filename: filename,
      size: size,
      folder: safeFolder,
      uri: uri,
      time: Date.now()
    })
    if (next.length > 64) next = next.slice(0, 64)
    storage.set({ key: STORAGE_KEY, value: JSON.stringify(next) })
  })
}

/** 删除已接收文件记录并删除文件 */
function deleteReceivedFile(uri, callback) {
  file.delete({
    uri: uri,
    success: function () {
      getReceivedFiles(function (list) {
        var next = []
        for (var i = 0; i < list.length; i++) {
          if (list[i] && list[i].uri !== uri) {
            next.push(list[i])
          }
        }
        storage.set({ key: STORAGE_KEY, value: JSON.stringify(next) })
        if (callback) callback(true)
      })
    },
    fail: function () {
      // 文件可能不存在，仍然从记录中删除
      getReceivedFiles(function (list) {
        var next = []
        for (var i = 0; i < list.length; i++) {
          if (list[i] && list[i].uri !== uri) {
            next.push(list[i])
          }
        }
        storage.set({ key: STORAGE_KEY, value: JSON.stringify(next) })
        if (callback) callback(true)
      })
    }
  })
}

/** 构建传输文件保存路径 */
function buildTransferUri(filename, folder) {
  var safeFolder = (typeof folder === 'string' && folder) ? folder : ''
  return TRANSFER_DIR + (safeFolder ? safeFolder + '/' : '') + filename
}

/** 获取存储使用量 */
function getStorageUsage(callback) {
  try {
    file.list({
      uri: TRANSFER_DIR,
      success: function (data) {
        var usage = 0
        if (data && data.fileList) {
          for (var i = 0; i < data.fileList.length; i++) {
            usage += data.fileList[i].length || 0
          }
        }
        callback(usage)
      },
      fail: function () {
        callback(0)
      }
    })
  } catch (e) {
    callback(0)
  }
}

/** 删除所有已接收文件 */
function deleteAllReceivedFiles(callback) {
  getReceivedFiles(function (list) {
    if (!list || list.length === 0) {
      if (callback) callback(0)
      return
    }
    var remaining = list.length
    var deleted = 0
    for (var i = 0; i < list.length; i++) {
      var uri = list[i].uri
      file.delete({
        uri: uri,
        success: function () {
          deleted++
          remaining--
          if (remaining === 0) {
            storage.set({ key: STORAGE_KEY, value: '[]' })
            storage.delete({ key: CURRENT_FILE_KEY })
            if (callback) callback(deleted)
          }
        },
        fail: function () {
          // 文件可能不存在，仍然计数
          deleted++
          remaining--
          if (remaining === 0) {
            storage.set({ key: STORAGE_KEY, value: '[]' })
            storage.delete({ key: CURRENT_FILE_KEY })
            if (callback) callback(deleted)
          }
        }
      })
    }
  })
}

export {
  createInterconnectTransfer,
  TRANSFER_DIR,
  STORAGE_KEY,
  getReceivedFiles,
  saveReceivedFile,
  deleteReceivedFile,
  deleteAllReceivedFiles,
  buildTransferUri,
  getStorageUsage
}
