/**
 * nav.js (v4.0)
 * 导航工具，带 600ms 防抖防止重复 push
 */
import router from '@system.router'

var _lastPush = 0
var DEBOUNCE_MS = 600

export default {
  push: function (uri, params) {
    var now = Date.now()
    if (now - _lastPush < DEBOUNCE_MS) return
    _lastPush = now
    router.push({
      uri: uri,
      params: params || {}
    })
  },
  replace: function (uri, params) {
    var now = Date.now()
    if (now - _lastPush < DEBOUNCE_MS) return
    _lastPush = now
    router.replace({
      uri: uri,
      params: params || {}
    })
  },
  back: function () {
    router.back()
  },
  resetDebounce: function () {
    _lastPush = 0
  }
}
