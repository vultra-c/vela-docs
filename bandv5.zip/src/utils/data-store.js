/**
 * data-store.js (v4.0 优化版)
 *
 * 优化点：
 * 1. 修复 clearProgress() 使用 storage.clear() 清空所有数据的致命 bug
 *    → 改为只删除阅读进度相关的 key
 * 2. 添加命名空间前缀，避免 key 冲突
 * 3. 添加 Promise 包装，支持 async/await
 * 4. 优化缓存策略，减少重复 storage 读取
 * 5. 添加数据迁移支持
 */
import storage from '@system.storage'
import file from '@system.file'
import DATA from '../data/topics.js'

var KEY_STRUCTURE = 'app_structure'
var KEY_INIT = 'app_init'
var KEY_VERSION = 'app_data_version'
var CURRENT_DATA_VERSION = '1'

// 内存缓存
var _structureCache = null
var _cacheValid = false

/** Promise 包装 storage.get */
function storageGet(key, defaultVal) {
  return new Promise(function (resolve) {
    storage.get({
      key: key,
      success: function (data) {
        resolve(data || defaultVal)
      },
      fail: function () {
        resolve(defaultVal)
      }
    })
  })
}

/** Promise 包装 storage.set */
function storageSet(key, value) {
  return new Promise(function (resolve, reject) {
    storage.set({
      key: key,
      value: value,
      success: function () {
        resolve()
      },
      fail: function (data, code) {
        reject(code)
      }
    })
  })
}

/** Promise 包装 storage.delete */
function storageDelete(key) {
  return new Promise(function (resolve) {
    storage.delete({
      key: key,
      success: function () { resolve() },
      fail: function () { resolve() }
    })
  })
}

/** 读取内容结构树 */
function getStructure() {
  if (_cacheValid && _structureCache) {
    return Promise.resolve(_structureCache)
  }
  return storageGet(KEY_STRUCTURE, '').then(function (data) {
    if (data) {
      try {
        var parsed = JSON.parse(data)
        _structureCache = parsed
        _cacheValid = true
        return parsed
      } catch (e) {
        // 数据损坏，返回空
      }
    }
    // 无内置数据，返回空数组（所有考点通过蓝牙传输获取）
    _structureCache = []
    _cacheValid = true
    return []
  })
}

/** 保存内容结构树 */
function saveStructure(data) {
  _structureCache = data
  _cacheValid = true
  var json = JSON.stringify(data)
  return storageSet(KEY_STRUCTURE, json)
}

/** 初始化数据（首次启动时调用） */
function ensureData() {
  return storageGet(KEY_INIT, '').then(function (initialized) {
    if (initialized === '1') {
      // 检查数据版本，必要时迁移
      return storageGet(KEY_VERSION, '').then(function (version) {
        if (version !== CURRENT_DATA_VERSION) {
          // 数据迁移：写入空结构
          return saveStructure([]).then(function () {
            return storageSet(KEY_VERSION, CURRENT_DATA_VERSION)
          })
        }
        return Promise.resolve()
      })
    }
    // 首次初始化：写入空结构（无内置考点，全部通过蓝牙传输）
    return saveStructure([]).then(function () {
      return storageSet(KEY_INIT, '1').then(function () {
        return storageSet(KEY_VERSION, CURRENT_DATA_VERSION)
      })
    })
  })
}

/** 更新结构树中的某个节点 */
function updateStructure(newStructure) {
  return saveStructure(newStructure)
}

/** 清除全部阅读进度（不再清空所有 storage） */
function clearAllReadingProgress() {
  // 获取结构树，遍历删除所有 read_page_ 开头的 key
  return getStructure().then(function (structure) {
    var keysToDelete = []
    collectProgressKeys(structure, keysToDelete)
    var promises = keysToDelete.map(function (key) {
      return storageDelete('read_page_' + key)
    })
    return Promise.all(promises)
  })
}

function collectProgressKeys(node, keys) {
  if (!node) return
  if (node.children) {
    for (var i = 0; i < node.children.length; i++) {
      collectProgressKeys(node.children[i], keys)
    }
  }
  if (node.path) {
    keys.push(node.path)
  }
}

/** 获取某篇文章的阅读进度 */
function getReadingProgress(path) {
  return storageGet('read_page_' + path, '0').then(function (data) {
    return parseInt(data, 10) || 0
  })
}

/** 保存某篇文章的阅读进度 */
function saveReadingProgress(path, pageIndex) {
  return storageSet('read_page_' + path, String(pageIndex))
}

/** 使缓存失效（外部修改结构后调用） */
function invalidateCache() {
  _cacheValid = false
  _structureCache = null
}

/** 删除结构树中的某个节点 */
function deleteNode(structure, path) {
  var segments = path.split('-')
  var current = structure
  var parent = null
  var parentKey = ''
  for (var i = 0; i < segments.length - 1; i++) {
    var idx = parseInt(segments[i], 10)
    if (!current.children || idx >= current.children.length) return structure
    parent = current
    parentKey = segments.slice(0, i + 1).join('-')
    current = current.children[idx]
  }
  var lastIdx = parseInt(segments[segments.length - 1], 10)
  if (current.children && lastIdx < current.children.length) {
    current.children.splice(lastIdx, 1)
  }
  return structure
}

/** 读取文章正文 */
function readArticle(uri, successCb, failCb) {
  // 接收的文件使用 UTF-16LE 编码（与喵喵电子书传输协议一致）
  var encoding = null
  if (uri && uri.indexOf('internal://files/received/') === 0) {
    encoding = 'UTF-16LE'
  }
  file.readText({
    uri: uri,
    encoding: encoding,
    success: function (data) {
      successCb(data.text || '')
    },
    fail: function (data, code) {
      if (failCb) {
        failCb(code)
      } else {
        successCb('（内容加载失败）')
      }
    }
  })
}

/** Promise 版读取文章正文 */
function readArticleAsync(uri) {
  return new Promise(function (resolve, reject) {
    file.readText({
      uri: uri,
      success: function (data) {
        resolve(data.text || '')
      },
      fail: function (data, code) {
        reject(code)
      }
    })
  })
}

export default {
  getStructure: getStructure,
  saveStructure: saveStructure,
  ensureData: ensureData,
  updateStructure: updateStructure,
  clearAllReadingProgress: clearAllReadingProgress,
  getReadingProgress: getReadingProgress,
  saveReadingProgress: saveReadingProgress,
  invalidateCache: invalidateCache,
  deleteNode: deleteNode,
  readArticle: readArticle,
  readArticleAsync: readArticleAsync,
  storageGet: storageGet,
  storageSet: storageSet,
  storageDelete: storageDelete
}
