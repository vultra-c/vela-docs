/**
 * 本文件已清空内置知识点数据。
 * 所有考点内容均通过蓝牙传输从手机端推送，不再预置任何内容。
 * 保留空数组以兼容 data-store.js 的 import 引用。
 */

export const DATA = []
