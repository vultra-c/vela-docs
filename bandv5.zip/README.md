# 考点阅读器 v4.0 (ExamReader Vela)

小米手环9 Pro Vela 轻应用 - 优化版

## 项目结构

```
examreader-v4.0/
├── src/                          # Vela 手环端应用
│   ├── app.ux                    # 应用入口
│   ├── manifest.json             # 应用清单
│   ├── common/
│   │   └── license.js            # 授权验证
│   ├── components/
│   │   └── SimpleKeyboard/       # 轻量级键盘组件
│   │       └── SimpleKeyboard.ux
│   ├── data/
│   │   └── topics.js             # 内容结构树
│   ├── pages/
│   │   ├── index/index.ux        # 主页 + 设置面板
│   │   ├── list/list.ux          # 列表/导航页
│   │   ├── reader/reader.ux      # 阅读器
│   │   ├── transfer/transfer.ux  # 文件传输页（蓝牙）
│   │   ├── search/search.ux      # 搜索页
│   │   └── payment/payment.ux    # 授权激活页
│   └── utils/
│       ├── data-store.js         # 存储抽象层
│       ├── interconnect-transfer.js  # 蓝牙传输协议
│       ├── device-adapt.js       # 设备适配
│       └── nav.js                # 导航工具
├── android-companion/            # Android 手机端配套应用
│   ├── app/src/main/java/com/application/examreader/
│   │   ├── App.kt                # Application
│   │   ├── MainActivity.kt       # 主界面
│   │   ├── PushActivity.kt       # 推送界面
│   │   ├── logic/
│   │   │   ├── Interconn.kt      # 连接层
│   │   │   ├── InterHandshake.kt # 握手协议
│   │   │   └── InterconnetFile.kt # 文件传输
│   │   ├── utils/FileUtils.kt    # 文件工具
│   │   └── ui/                   # Compose UI
│   └── ...
└── package.json
```

## v4.0 优化清单

### 蓝牙传输（核心新功能）
- [x] 完整实现基于 `@system.interconnect` 的文件传输协议
- [x] 三步握手协议（`__hs__` tag, count 0→1→2, 3秒超时）
- [x] ACK 确认流控（手表收到分片后回 next，手机才发下一片）
- [x] 错误恢复（序号不匹配时手表回 error + 期望序号，手机重传）
- [x] 断点续传（手表记录当前文件名和已接收长度）
- [x] 存储空间检查（25MB 上限）
- [x] GC 优化（每 10 个分片调用 `global.runGC()`）
- [x] Android 端配套 APP 完整实现

### Bug 修复
- [x] **修复 `clearProgress()` 使用 `storage.clear()` 清空所有数据的致命 bug**（改为只删除阅读进度 key）
- [x] 修复 `cancelReceiving()` 调用 `start()` 而非 `cancel()` 的 bug
- [x] 修复 `jumpBy(n)` 后未调用 `showPage()` 导致页面不更新的 bug
- [x] 修复 `that.valid` 缺少 `$` 前缀的 bug
- [x] 修复重复 `stopPropagation()` 方法定义
- [x] 修复搜索 `onComplete` 无长度限制问题
- [x] 修复 `versionTapTimer` 未在 `onDestroy` 中清理

### 性能优化
- [x] 内存泄漏修复：导航离开时清理 `fullContent`/`pages`/`_pageCache`
- [x] 使用轻量 SimpleKeyboard（~230行）替代 615 行 InputMethod
- [x] 分页缓存使用 `path:length` 作为键，避免重复分页
- [x] 搜索预计算小写文本，避免重复 `toLowerCase()`
- [x] 分块搜索使用 `setTimeout(0)` 让出 UI 线程
- [x] 全局方法挂载到 `global`，减少 bundle 大小
- [x] `onShow` 仅在需要时重建 entries

### 存储优化
- [x] 数据缓存策略，减少重复 `storage.get`
- [x] Promise 包装 storage API，支持 async/await
- [x] 数据版本管理 + 迁移支持
- [x] 已接收文件列表管理（增删查）
- [x] 文件名安全过滤，防止路径遍历

### 体验优化
- [x] 传输进度实时显示（百分比 + 分片数）
- [x] 传输状态机（等待→连接→接收→成功/失败）
- [x] 续传模式提示
- [x] 存储用量显示
- [x] 长按删除已接收文件
- [x] 文件大小显示
- [x] 关于/更新日志弹窗

## 构建说明

### Vela 手环端
```bash
npm install
npx aiot build
# 生成 build/ 目录，包含 app.js 和 manifest.json
```

### Android 手机端
1. 将 `xms-wearable-lib_1.4_release.aar` 复制到 `android-companion/app/libs/`
2. 生成 Gradle wrapper: `gradle wrapper --gradle-version 8.11.1`
3. 构建: `./gradlew assembleDebug`
4. 安装: `adb install -r app/build/outputs/apk/debug/app-debug.apk`

## 传输协议

手机和手环通过小米运动健康 APP 的 interconnect 通道通信：

```
手机 (Android)                    手环 (Vela)
     |                                |
     |--- openApp /pages/transfer --->|
     |--- __hs__ count=0 ------------>|
     |<-- __hs__ count=1 -------------|
     |--- __hs__ count=2 ------------>|
     |                                |
     |--- file startTransfer -------->|
     |<-- file ready -----------------|
     |--- file d count=0 ------------>|
     |<-- file next count=1 ----------|
     |--- file d count=1 ------------>|
     |<-- file next count=2 ----------|
     |          ...                   |
     |--- file d count=N ------------>|
     |<-- file success ---------------|
```
