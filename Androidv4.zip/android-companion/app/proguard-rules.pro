# ProGuard / R8 rules for the ExamReader companion app.
# Release minify is disabled by default; these rules apply if you enable it.

-keepattributes *Annotation*, InnerClasses, Signature, Exceptions

# ---- Kotlinx Serialization ----
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
# Keep all @Serializable model classes used by the protocol
-keep,includedescriptorclasses class com.application.examreader.logic.**$$serializer { *; }
-keepclassmembers class com.application.examreader.logic.** {
    *** Companion;
}
-keepclasseswithmembers class com.application.examreader.logic.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# ---- Xiaomi XMS Wearable SDK ----
-keep class com.xiaomi.xms.wearable.** { *; }
-dontwarn com.xiaomi.xms.wearable.**

# ---- juniversalchardet ----
-keep class org.mozilla.universalchardet.** { *; }
