package com.application.examreader.utils

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import kotlin.math.roundToInt

/**
 * File helpers: Uri -> File conversion, a best-effort real-path lookup and a
 * human-readable byte formatter.
 */
object FileUtils {

    /**
     * Convert a content/file [uri] to a [File] by copying it into the app's
     * cache directory (needed for content:// uris returned by the document
     * picker). Returns null if the scheme is unsupported or copying fails.
     */
    fun uriToFile(uri: Uri?, context: Context): File? {
        var file: File? = null
        if (uri == null) return file

        if (uri.scheme == ContentResolver.SCHEME_FILE) {
            file = File(uri.path!!)
        } else if (uri.scheme == ContentResolver.SCHEME_CONTENT) {
            val contentResolver = context.contentResolver
            val cursor = contentResolver.query(uri, null, null, null, null)
            val displayName = cursor?.use {
                if (it.moveToFirst()) {
                    it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                } else {
                    null
                }
            } ?: ((System.currentTimeMillis() + ((Math.random() + 1) * 1000).roundToInt()).toString() +
                    "." + (MimeTypeMap.getSingleton()
                .getExtensionFromMimeType(contentResolver.getType(uri)) ?: "txt"))

            try {
                val ins: InputStream = contentResolver.openInputStream(uri)!!
                val cache = File(context.cacheDir.absolutePath, displayName)
                val fos = FileOutputStream(cache)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    android.os.FileUtils.copy(ins, fos)
                } else {
                    ins.copyTo(fos)
                }
                file = cache
                fos.close()
                ins.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        return file
    }

    /** Best-effort real filesystem path for display/debug purposes. */
    fun getRealPath(context: Context, uri: Uri?): String {
        if (uri == null) return ""
        val f = uriToFile(uri, context)
        return f?.absolutePath ?: uri.toString()
    }
}

/** Format a byte count (Long) as a human-readable string, e.g. "1.23 MB". */
fun bytesToReadable(bytes: Long): String = bytesToReadable(bytes.toDouble())

/** Format a byte count (Double) as a human-readable string. */
fun bytesToReadable(bytes: Double): String {
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var b = bytes
    var i = 0
    while (b >= 1024 && i < units.size - 1) {
        b /= 1024
        i++
    }
    return String.format("%.2f %s", b, units[i])
}
