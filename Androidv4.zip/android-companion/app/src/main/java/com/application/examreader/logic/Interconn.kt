package com.application.examreader.logic

import android.content.Context
import android.util.Log
import com.xiaomi.xms.wearable.Wearable.getAuthApi
import com.xiaomi.xms.wearable.Wearable.getMessageApi
import com.xiaomi.xms.wearable.Wearable.getNodeApi
import com.xiaomi.xms.wearable.auth.AuthApi
import com.xiaomi.xms.wearable.auth.Permission
import com.xiaomi.xms.wearable.message.MessageApi
import com.xiaomi.xms.wearable.message.OnMessageReceivedListener
import com.xiaomi.xms.wearable.node.Node
import com.xiaomi.xms.wearable.node.NodeApi
import kotlinx.coroutines.CompletableDeferred
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Base interconnect layer wrapping the Xiaomi XMS Wearable SDK
 * (NodeApi / AuthApi / MessageApi).
 *
 * All protocol payloads are JSON strings. Every message carries a `"tag"`
 * field used to route incoming messages to the registered listener of the
 * same tag (see [addListener]).
 *
 * The watch app this pairs with is the ExamReader Vela quick app
 * (package `com.application.examreader`); its transfer entry page lives at
 * `/pages/transfer` (see [openApp]).
 */
open class Interconn(context: Context) {

    val nodeApi: NodeApi = getNodeApi(context)
    val authApi: AuthApi = getAuthApi(context)
    val messageApi: MessageApi = getMessageApi(context)
    var currentNode: Node? = null

    val json = Json {
        ignoreUnknownKeys = true
    }

    /** Tag -> callback routing table for incoming JSON messages. */
    val onMessage = mutableMapOf<String, (String) -> Unit>()

    /**
     * Default incoming-message listener. Decodes the raw bytes to a JSON
     * string, reads the `tag` field and dispatches to [onMessage].
     * Subclasses (e.g. [InterHandshake]) override this to add behaviour such
     * as a watchdog timer.
     */
    open val onMessageListener = OnMessageReceivedListener { _, message ->
        val messageStr = message.decodeToString()
        Log.d("Interconn", messageStr)
        val msg = json.decodeFromString<Message>(messageStr)
        onMessage[msg.tag]?.invoke(messageStr)
    }

    /**
     * Find the first connected wearable node.
     * @return the device name on success.
     */
    fun connect(): CompletableDeferred<String> {
        return CompletableDeferred<String>().apply {
            nodeApi.connectedNodes.addOnSuccessListener {
                if (it.isEmpty()) {
                    completeExceptionally(Exception("未找到设备！"))
                    return@addOnSuccessListener
                }
                currentNode = it[0]
                complete(currentNode!!.name)
            }.addOnFailureListener {
                completeExceptionally(Exception("获取设备列表失败，请检查小米运动健康是否已连接！"))
            }
        }
    }

    /**
     * Request/check the DEVICE_MANAGER permission for the current node.
     */
    fun auth(): CompletableDeferred<Unit> {
        val permissions = arrayOf<Permission?>(Permission.DEVICE_MANAGER)
        return CompletableDeferred<Unit>().apply {
            authApi.checkPermissions(currentNode!!.id, permissions).addOnSuccessListener {
                for ((index, value) in it.withIndex()) {
                    if (!value) {
                        authApi.requestPermission(currentNode!!.id, permissions[index])
                            .addOnFailureListener {
                                Log.e("Auth", "requestPermission failed", it)
                            }
                    }
                }
                complete(Unit)
            }.addOnFailureListener {
                completeExceptionally(Exception("获取权限失败！"))
            }
        }
    }

    /**
     * Launch the ExamReader transfer page on the watch.
     *
     * CRITICAL: this must open `/pages/transfer` (the Vela app's transfer
     * route), NOT `/pages/push`. The watch app listens for the interconnect
     * connection on its transfer page.
     */
    fun openApp(): CompletableDeferred<Unit> {
        return CompletableDeferred<Unit>().apply {
            nodeApi.launchWearApp(currentNode!!.id, "/pages/transfer").addOnSuccessListener {
                Log.d("OpenApp", "success /pages/transfer")
                complete(Unit)
            }.addOnFailureListener {
                Log.e("OpenApp", "fail", it)
                completeExceptionally(Exception("打开应用失败！"))
            }
        }
    }

    /**
     * Register [onMessageListener] for the current node.
     */
    fun registerListener(): CompletableDeferred<Unit> {
        return CompletableDeferred<Unit>().apply {
            messageApi.addListener(currentNode!!.id, onMessageListener).addOnSuccessListener {
                complete(Unit)
            }.addOnFailureListener { completeExceptionally(it) }
        }
    }

    /**
     * Send a raw JSON string to the watch.
     */
    open fun sendMessage(message: String): CompletableDeferred<Unit> {
        Log.d("Interconn", message)
        return CompletableDeferred<Unit>().apply {
            messageApi.sendMessage(currentNode!!.id, message.toByteArray()).addOnSuccessListener {
                complete(Unit)
            }.addOnFailureListener {
                Log.e("Send", "fail", it)
                completeExceptionally(it)
            }
        }
    }

    fun addListener(type: String, callback: (String) -> Unit) {
        onMessage[type] = callback
    }

    fun removeListener(type: String) {
        onMessage.remove(type)
    }

    /** Query whether the ExamReader Vela app is installed on the watch. */
    fun getAppState(): CompletableDeferred<Boolean> {
        return CompletableDeferred<Boolean>().apply {
            nodeApi.isWearAppInstalled(currentNode!!.id)
                .addOnSuccessListener { complete(it) }
                .addOnFailureListener { completeExceptionally(it) }
        }
    }

    /**
     * Remove the message listener for the current node. Safe to call
     * multiple times.
     *
     * NOTE: this intentionally does *not* clear [currentNode]. Callers such as
     * [InterconnetFile.sentFile] and [InterconnetFile.cancel] issue further
     * API calls (registerListener / sendMessage) right after destroy(), so
     * nulling the node here would cause NPEs. Reconnection is handled by
     * [connect] (which always overwrites [currentNode]) in the main activity.
     */
    fun destroy(): CompletableDeferred<Unit> {
        return CompletableDeferred<Unit>().apply {
            val node = currentNode
            if (node == null) {
                complete(Unit)
            } else {
                messageApi.removeListener(node.id).addOnSuccessListener {
                    complete(Unit)
                }.addOnFailureListener {
                    complete(Unit)
                }
            }
        }
    }

    /**
     * Convenience: connect -> auth -> openApp. No-op if already initialised.
     */
    suspend fun init() {
        if (currentNode != null) return
        connect().await()
        auth().await()
        openApp().await()
    }

    @Serializable
    data class Message(val tag: String)
}
