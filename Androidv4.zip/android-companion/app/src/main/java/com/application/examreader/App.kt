package com.application.examreader

import android.app.Application
import com.application.examreader.logic.InterHandshake

/**
 * Application instance holding the shared [InterHandshake] connection.
 *
 * The connection is created once in [MainActivity] (using that activity's
 * lifecycle scope) and shared with [PushActivity] through this field, so the
 * Bluetooth link, listener registration and handshake state survive the
 * navigation from the main screen to the push screen.
 */
class App : Application() {
    lateinit var conn: InterHandshake
}
