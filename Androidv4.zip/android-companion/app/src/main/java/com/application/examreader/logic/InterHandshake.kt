package com.application.examreader.logic

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.xiaomi.xms.wearable.message.OnMessageReceivedListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

/**
 * 3-way handshake protocol layered on top of [Interconn].
 *
 * Protocol (tag `"__hs__"`):
 *   {"tag":"__hs__","count":0}  phone initiates
 *   {"tag":"__hs__","count":1}  watch responds
 *   {"tag":"__hs__","count":2}  phone confirms
 *
 * A watchdog timer is reset on every incoming message. If no message arrives
 * within [TIMEOUT] milliseconds, [onDisconnected] is invoked. The first
 * outgoing [sendMessage] blocks until the handshake completes (or fails with a
 * timeout), so callers can treat the channel as ready once it returns.
 */
class InterHandshake(
    context: Context,
    val scope: CoroutineScope,
) : Interconn(context) {

    companion object {
        private const val TYPE = "__hs__"
        private const val TIMEOUT = 3000L
    }

    private var promise: Deferred<Unit>? = null
    private var connected = false
    private var resolve: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())
    private var timeoutRunnable: Runnable? = null

    /**
     * Overrides the base listener to (a) reset the watchdog on every message
     * and (b) dispatch by tag as usual.
     */
    override val onMessageListener = OnMessageReceivedListener { _, message ->
        // Reset the watchdog timer on every incoming message.
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = Runnable {
            promise = null
            resolve = null
            connected = false
            onDisconnected.invoke()
        }
        handler.postDelayed(timeoutRunnable!!, TIMEOUT)

        val messageStr = message.decodeToString()
        Log.d("InterconnIn", messageStr)
        val msg = json.decodeFromString<Message>(messageStr)
        onMessage[msg.tag]?.invoke(messageStr)
    }

    init {
        // Register the handshake message listener.
        addListener(TYPE) { payload ->
            val data: HandshakePayload = json.decodeFromString(payload)
            val currentCount = data.count

            // count > 0 means the peer has answered: complete the handshake.
            if (currentCount > 0) {
                if (promise != null) {
                    resolve?.invoke()
                    resolve = null
                    promise = null
                    onConnected.invoke()
                } else {
                    promise = CompletableDeferred(Unit)
                }
            }

            // Increment the count and continue the handshake (cap at 2).
            val newCount = currentCount + 1
            if (newCount < 3) {
                super.sendMessage("{\"tag\":\"$TYPE\",\"count\":$newCount}")
            }
        }
    }

    /**
     * Send a message, waiting for the handshake to complete first. If no
     * handshake is in progress, this kicks one off (count = 0). Fails with
     * "握手超时" if the watch does not answer within [TIMEOUT].
     */
    override fun sendMessage(message: String): CompletableDeferred<Unit> {
        return CompletableDeferred<Unit>().apply {
            val cpe = { e: Exception -> completeExceptionally(e) }
            scope.launch {
                if (!connected) {
                    if (promise != null) {
                        promise?.await()
                    } else {
                        // Initiate the handshake (count = 0).
                        promise = CompletableDeferred<Unit>().apply {
                            val timeoutCb = Runnable {
                                promise = null
                                resolve = null
                                connected = false
                                cpe(Exception("握手超时"))
                            }
                            handler.postDelayed(timeoutCb, TIMEOUT)
                            resolve = {
                                complete(Unit)
                                Log.i("handShake", "success")
                                handler.removeCallbacks(timeoutCb)
                                connected = true
                            }
                            super.sendMessage("{\"tag\":\"$TYPE\",\"count\":0}").await()
                        }
                        promise?.await()
                    }
                }
                complete(super.sendMessage(message).await())
            }
        }
    }

    @Serializable
    private data class HandshakePayload(val count: Int, val tag: String)

    private var onConnected: () -> Unit = {}
    fun setOnConnected(callback: () -> Unit) {
        onConnected = callback
    }

    private var onDisconnected: () -> Unit = {}
    fun setOnDisconnected(callback: () -> Unit) {
        onDisconnected = callback
    }
}
