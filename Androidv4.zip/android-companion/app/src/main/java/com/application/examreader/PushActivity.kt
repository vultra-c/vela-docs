package com.application.examreader

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.application.examreader.logic.InterconnetFile
import com.application.examreader.ui.components.ExamScaffold
import com.application.examreader.ui.components.SecondaryButton
import com.application.examreader.ui.theme.ExamReaderTheme
import com.application.examreader.utils.FileUtils
import com.application.examreader.utils.bytesToReadable

/**
 * Push screen: shows transfer progress (filename, size, progress bar, chunk
 * preview, speed) and a cancel/finish button. Drives
 * [InterconnetFile.sentFile].
 */
class PushActivity : ComponentActivity() {

    private lateinit var conn: com.application.examreader.logic.InterHandshake
    private lateinit var fileconn: InterconnetFile

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        conn = (application as App).conn
        fileconn = InterconnetFile(conn)
        if (fileconn.busy) {
            Toast.makeText(this, "文件推送中", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        enableEdgeToEdge()
        setContent {
            PushActivityPage()
        }
    }

    override fun onStop() {
        super.onStop()
        if (fileconn.busy) fileconn.cancel()
    }

    @Composable
    private fun PushActivityPage() {
        ExamReaderTheme {
            ExamScaffold(
                title = "推送中",
                onBack = { finish() }
            ) { padding ->
                Push(Modifier.fillMaxSize().padding(padding))
            }
        }
    }

    @Composable
    private fun Push(modifier: Modifier) {
        var filename by remember { mutableStateOf(".txt") }
        var filesize by remember { mutableStateOf("0 MB") }
        var progress by remember { mutableDoubleStateOf(0.0) }
        var chunkPreview by remember { mutableStateOf("...") }
        var speedText by remember { mutableStateOf(" --") }
        var statusIcon by remember { mutableStateOf(Icons.Filled.CloudUpload) }
        var btnText by remember { mutableStateOf("取消") }

        LaunchedEffect(Unit) {
            try {
                conn.init()
                intent.data?.let { uri ->
                    val file = FileUtils.uriToFile(uri, this@PushActivity) ?: return@let
                    filename = file.name
                    filesize = bytesToReadable(file.length())
                    fileconn.sentFile(
                        file = file,
                        onError = { error, count ->
                            runOnUiThread {
                                Toast.makeText(
                                    this@PushActivity,
                                    "文件上传失败,$error",
                                    Toast.LENGTH_SHORT
                                ).show()
                                statusIcon = Icons.Filled.Error
                                btnText = "取消"
                            }
                        },
                        onSuccess = { msg, count ->
                            runOnUiThread {
                                Toast.makeText(this@PushActivity, "文件上传成功", Toast.LENGTH_SHORT).show()
                                statusIcon = Icons.Filled.CheckCircle
                                btnText = "完成"
                            }
                        },
                        onProgress = { p, preview, speed ->
                            progress = p
                            chunkPreview = preview
                            speedText = speed
                        },
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this@PushActivity,
                        "连接失败: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                    statusIcon = Icons.Filled.Error
                    btnText = "返回"
                }
            }
        }

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                statusIcon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .padding(top = 40.dp)
                    .size(96.dp)
            )

            Text(
                text = filename,
                modifier = Modifier.padding(top = 20.dp),
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp
            )
            Text(
                text = filesize,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp
            )

            Card(
                modifier = Modifier
                    .padding(top = 20.dp)
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    text = chunkPreview,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .padding(16.dp),
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Text(
                text = "正在推送 ${(progress * 100).toInt()}%$speedText",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 16.dp)
            )

            LinearProgressIndicator(
                progress = { progress.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
            )

            SecondaryButton(
                text = btnText,
                onClick = { finish() }
            )

            Spacer(modifier = Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
        }
    }
}
