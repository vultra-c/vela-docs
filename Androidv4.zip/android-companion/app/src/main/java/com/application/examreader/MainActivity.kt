package com.application.examreader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.application.examreader.logic.InterHandshake
import com.application.examreader.ui.components.AboutDialog
import com.application.examreader.ui.components.ExamScaffold
import com.application.examreader.ui.components.InfoCard
import com.application.examreader.ui.components.PrimaryButton
import com.application.examreader.ui.components.SecondaryButton
import com.application.examreader.ui.theme.ExamReaderTheme
import com.application.examreader.utils.FileUtils
import com.application.examreader.utils.bytesToReadable
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.math.max

/**
 * Main screen: device connection card, file selection card and the push
 * action that launches [PushActivity].
 */
class MainActivity : ComponentActivity() {

    private lateinit var conn: InterHandshake
    private lateinit var filePicker: ActivityResultLauncher<Array<String>>
    private lateinit var fileHandler: (Uri?) -> Unit
    private var fileuri: Uri? = null
    private var isFileSelected = false
    private var updateDevice: () -> Unit = {}

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        conn = InterHandshake(this, lifecycleScope)
        (application as App).conn = conn
        filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { fileHandler(it) }
        setContent {
            MainActivityPage()
        }
    }

    override fun onDestroy() {
        conn.destroy()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        updateDevice()
    }

    @Composable
    private fun MainActivityPage() {
        var showAboutDialog by remember { mutableStateOf(false) }
        var showButtons by remember { mutableStateOf(false) }
        var isConnected by remember { mutableStateOf(false) }

        // Request runtime Bluetooth permissions on Android 12+ (best effort;
        // the XMS SDK routes through Mi Fitness, so we proceed regardless).
        val permLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { /* result ignored */ }
        LaunchedEffect(Unit) {
            val perms = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                perms.add(Manifest.permission.BLUETOOTH_SCAN)
                perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (perms.isNotEmpty()) {
                val toRequest = perms.filter {
                    ContextCompat.checkSelfPermission(this@MainActivity, it) !=
                            PackageManager.PERMISSION_GRANTED
                }
                if (toRequest.isNotEmpty()) {
                    permLauncher.launch(toRequest.toTypedArray())
                }
            }
        }

        ExamReaderTheme {
            val context = LocalContext.current
            val versionName = remember {
                try {
                    @Suppress("DEPRECATION")
                    context.packageManager.getPackageInfo(context.packageName, 0).versionName
                        ?: "unknown"
                } catch (e: Exception) {
                    "unknown"
                }
            }

            if (showAboutDialog) {
                AboutDialog(
                    onDismiss = { showAboutDialog = false },
                    onConfirm = { showAboutDialog = false },
                    versionName = versionName,
                )
            }

            ExamScaffold(
                title = "考点阅读器同步器",
                onBack = { finish() },
                onMenu = { showAboutDialog = !showAboutDialog }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(10.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        DeviceCard(onConnectedChange = { isConnected = it })
                        FileSelectCard { show ->
                            showButtons = show
                            isFileSelected = show
                        }
                    }

                    AnimatedVisibility(
                        visible = showButtons,
                        enter = slideInVertically { fullHeight -> -fullHeight } + fadeIn(),
                        exit = slideOutVertically { fullHeight -> -fullHeight } + fadeOut(),
                    ) {
                        Column {
                            SecondaryButton(text = "重新选择") {
                                filePicker.launch(arrayOf("text/plain"))
                            }
                            PrimaryButton(
                                text = "推送",
                                enabled = isConnected,
                            ) {
                                if (!isConnected) return@PrimaryButton
                                val intent = Intent(this@MainActivity, PushActivity::class.java)
                                    .setData(fileuri)
                                startActivity(intent)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Text(
                        text = "v${versionName}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(bottom = 10.dp)
                    )

                    Spacer(modifier = Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
                }
            }
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Composable
    private fun DeviceCard(onConnectedChange: (Boolean) -> Unit) {
        var icon by remember { mutableStateOf(Icons.Filled.HourglassEmpty) }
        var connState by remember { mutableStateOf("手环连接中") }
        var connDesc by remember { mutableStateOf("请确保小米运动健康后台运行") }
        val scope = rememberCoroutineScope()

        suspend fun initConn() {
            try {
                conn.destroy().await()
                val deviceName = conn.connect().await().replace(" ", "")
                conn.auth()
                try {
                    if (!conn.getAppState().await()) {
                        connState = "考点阅读器未安装"
                        connDesc = "请在手环上安装考点阅读器"
                        icon = Icons.Filled.HelpOutline
                        return
                    }
                } catch (e: Exception) {
                    connState = "考点阅读器未安装"
                    connDesc = "请在手环上安装考点阅读器"
                    icon = Icons.Filled.HelpOutline
                    return
                }
                conn.openApp()
                connState = "设备连接成功"
                connDesc = "$deviceName 已连接"
                icon = Icons.Filled.BluetoothConnected
                onConnectedChange(true)
            } catch (e: Exception) {
                Log.e("init", "connect fail ${e.message}")
                icon = Icons.Filled.BluetoothDisabled
                connState = "手环连接失败"
                connDesc = e.message ?: "未知错误"
                onConnectedChange(false)
            }
        }

        InfoCard(
            icon = icon,
            iconTint = MaterialTheme.colorScheme.primary,
            title = connState,
            description = connDesc,
            onClick = { GlobalScope.launch { initConn() } },
        )

        LaunchedEffect(Unit) {
            initConn()
            updateDevice = {
                scope.launch { initConn() }
            }
        }
    }

    @Composable
    private fun FileSelectCard(callback: (Boolean) -> Unit) {
        var icon by remember { mutableStateOf(Icons.Filled.NoteAdd) }
        var filename by remember { mutableStateOf("选取文本文件") }
        var fileDesc by remember { mutableStateOf("请选取 txt 文件") }

        fileHandler = fileHandler@{ uri ->
            if (uri == null) {
                if (!isFileSelected) return@fileHandler
                filename = "选取文本文件"
                fileDesc = "请选取 txt 文件"
                icon = Icons.Filled.NoteAdd
                callback(false)
                return@fileHandler
            }
            fileuri = uri
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    filename = it.getString(max(it.getColumnIndex(OpenableColumns.DISPLAY_NAME), 0))
                    icon = Icons.Filled.Description
                    val size = it.getLong(max(it.getColumnIndex(OpenableColumns.SIZE), 0))
                    fileDesc = if (size != -1L) bytesToReadable(size) else "未知大小"
                    callback(true)
                }
            }
        }

        InfoCard(
            icon = icon,
            title = filename,
            description = fileDesc,
            onClick = {
                if (isFileSelected) {
                    Toast.makeText(this, FileUtils.getRealPath(this, fileuri), Toast.LENGTH_SHORT).show()
                } else {
                    filePicker.launch(arrayOf("text/plain"))
                }
            },
        )

        LaunchedEffect(Unit) {
            intent.data?.let { fileHandler(it) }
        }
    }
}
