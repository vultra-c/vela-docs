package com.application.examreader.logic

import android.util.Log
import com.application.examreader.utils.bytesToReadable
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.mozilla.universalchardet.UniversalDetector
import java.io.File
import java.nio.charset.Charset

/**
 * File transfer protocol over an [InterHandshake] channel.
 *
 * Text is chunked by UTF-16LE bytes in [FILE_SIZE]-byte pieces and streamed
 * to the watch with ACK flow control (the watch asks for the next chunk only
 * after it has written the current one).
 *
 * Protocol messages (all carry tag `"file"`):
 *
 * Phone -> Watch:
 *   {"tag":"file","stat":"startTransfer","filename":"x.txt","total":N,"chunkSize":20480}
 *   {"tag":"file","stat":"d","count":N,"data":"...","setCount":N?}
 *   {"tag":"file","stat":"cancel"}
 *
 * Watch -> Phone:
 *   {"tag":"file","type":"ready","found":false,"usage":12345}
 *   {"tag":"file","type":"ready","found":true,"length":15000,"usage":12345}
 *   {"tag":"file","type":"next","message":"N success","count":N+1}
 *   {"tag":"file","type":"error","message":"package count error","count":N}
 *   {"tag":"file","type":"success","message":"transfer success","count":N+1}
 *   {"tag":"file","type":"cancel"}
 */
class InterconnetFile(private val conn: InterHandshake) {

    /** Size of each chunk in bytes (20 KB). */
    private val FILE_SIZE = 1024 * 20

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
    }

    private lateinit var chunks: List<String>
    private lateinit var file: File
    private var lastChunkTime: Long = 0

    private lateinit var onError: (message: String, count: Int) -> Unit
    private lateinit var onSuccess: (message: String, count: Int) -> Unit
    private lateinit var onProgress: (progress: Double, chunkPreview: String, status: String) -> Unit

    /** True while a transfer is in progress. */
    var busy = false

    init {
        conn.addListener("file") listener@{
            try {
                val type = json.decodeFromString<FileMessagesFromDevice.Header>(it).type
                when (type) {
                    "ready" -> {
                        val jsonMessage = json.decodeFromString<FileMessagesFromDevice.Ready>(it)
                        // Storage guard: refuse if the watch is too full.
                        if (jsonMessage.usage > 25 * 1024 * 1024) {
                            onError("存储空间不足", 0)
                            busy = false
                            conn.destroy()
                            return@listener
                        }
                        if (jsonMessage.found && jsonMessage.length?.toInt()!! > 0) {
                            // Resume: derive the chunk index from the length
                            // the watch already holds.
                            val currentChunk = jsonMessage.length / FILE_SIZE
                            if (currentChunk.toInt() > chunks.size) {
                                sendNextChunk(0, true)
                            } else {
                                sendNextChunk(currentChunk.toInt(), true)
                            }
                        } else {
                            sendNextChunk(0)
                        }
                    }

                    "error" -> {
                        val jsonMessage = json.decodeFromString<FileMessagesFromDevice.Error>(it)
                        // Watch reported a sequence mismatch: resend the
                        // chunk it expects.
                        sendNextChunk(jsonMessage.count)
                    }

                    "success" -> {
                        busy = false
                        val jsonMessage = json.decodeFromString<FileMessagesFromDevice.Success>(it)
                        onSuccess(jsonMessage.message, jsonMessage.count)
                        conn.destroy()
                    }

                    "next" -> {
                        val jsonMessage = json.decodeFromString<FileMessagesFromDevice.Next>(it)
                        sendNextChunk(jsonMessage.count)
                    }

                    "cancel" -> {
                        busy = false
                        conn.destroy()
                        onSuccess("取消传输", 0)
                    }

                    "usage" -> TODO()
                }
            } catch (e: Exception) {
                Log.e("file", "Error parsing JSON message: $it", e)
            }
        }
    }

    /**
     * Main entry point. Opens the watch app, registers the listener and kicks
     * off the transfer by sending `startTransfer`.
     */
    suspend fun sentFile(
        file: File,
        onError: (message: String, count: Int) -> Unit,
        onSuccess: (message: String, count: Int) -> Unit,
        onProgress: (progress: Double, String, status: String) -> Unit,
    ) {
        conn.init()
        conn.destroy().await()
        conn.registerListener().await()
        conn.setOnDisconnected {
            busy = false
            onError("连接断开", 0)
        }

        this.file = file

        val chunkSize = FILE_SIZE
        // Read raw bytes and auto-detect the source charset.
        val fileBytes = file.readBytes()
        val detected = detectCharset(fileBytes)
        val content = fileBytes.toString(Charset.forName(detected))
        // Chunk the decoded text by UTF-16LE bytes.
        chunks = content.chunkedByBytes(chunkSize, charset = Charsets.UTF_16LE)

        busy = true
        onProgress(0.0, chunks[0], " --")
        delay(1000L) // give the watch app a moment to open

        conn.sendMessage(
            json.encodeToString(
                FileMessagesToSend.StartTransfer(
                    filename = file.name,
                    total = chunks.size,
                    chunkSize = FILE_SIZE
                )
            )
        )

        this.onError = onError
        this.onSuccess = onSuccess
        this.onProgress = onProgress
        Log.d("File", "sentFile")
    }

    /** Auto-detect the charset of a byte array, falling back to UTF-16LE. */
    private fun detectCharset(bytes: ByteArray): String {
        val detector = UniversalDetector(null)
        detector.handleData(bytes, 0, bytes.size)
        detector.dataEnd()
        val charset = detector.detectedCharset ?: "UTF-16LE"
        detector.reset()
        return charset
    }

    /**
     * Send chunk [currentChunk]. When [isReSend] is true (resume / error
     * recovery) the `setCount` field is populated so the watch resets its
     * expected sequence number.
     */
    private fun sendNextChunk(currentChunk: Int, isReSend: Boolean = false) {
        val chunk = chunks[currentChunk]
        val message = FileMessagesToSend.DataChunk(
            count = currentChunk,
            data = chunk,
            setCount = if (isReSend) currentChunk else null
        )

        // Speed / ETA calculation.
        val currentTime = System.currentTimeMillis()
        if (lastChunkTime != 0L) {
            val timeTaken = currentTime - lastChunkTime
            val speed = bytesToReadable(FILE_SIZE / (timeTaken / 1000.0))
            val remainingTime = (chunks.size - currentChunk) * (currentTime - lastChunkTime) / 1000.0
            onProgress(
                currentChunk.toDouble() / chunks.size,
                chunks[currentChunk],
                " $speed/s ${remainingTime.toInt()}s"
            )
        } else {
            onProgress(currentChunk.toDouble() / chunks.size, chunks[currentChunk], " --")
        }
        lastChunkTime = currentTime

        conn.sendMessage(json.encodeToString(message)).invokeOnCompletion {
            if (it != null) {
                onError("发送失败", currentChunk)
            }
        }

        // Local completion guard (mirrors the watch's success signal).
        if (currentChunk >= chunks.size - 1) {
            busy = false
            onProgress(1.0, chunks[0], " --")
            onSuccess("传输完成", chunks.size)
            conn.setOnDisconnected { }
            conn.destroy()
        }

        Log.d("File", "sendNextChunk$currentChunk")
    }

    /** Cancel an in-progress transfer. */
    fun cancel() {
        conn.setOnDisconnected { }
        conn.destroy()
        busy = false
        conn.sendMessage(json.encodeToString(FileMessagesToSend.Cancel()))
    }

    // ------------------------------------------------------------------
    //  Protocol message models
    // ------------------------------------------------------------------

    @Serializable
    private sealed class FileMessagesFromDevice {
        @Serializable
        data class Header(
            val tag: String = "file",
            val type: String
        ) : FileMessagesFromDevice()

        /** Ready state (new file or resume). */
        @Serializable
        data class Ready(
            val type: String = "ready",
            val found: Boolean,          // file already present on the watch?
            val usage: Long,             // current storage usage (bytes)
            val length: Long? = null     // present only when found=true (bytes already received)
        ) : FileMessagesFromDevice()

        /** Sequence mismatch / write error. */
        @Serializable
        data class Error(
            val type: String = "error",
            val message: String,
            val count: Int               // expected chunk index
        ) : FileMessagesFromDevice()

        /** All chunks received. */
        @Serializable
        data class Success(
            val type: String = "success",
            val message: String,
            val count: Int
        ) : FileMessagesFromDevice()

        /** Ask for the next chunk. */
        @Serializable
        data class Next(
            val type: String = "next",
            val message: String,
            val count: Int               // received chunk index
        ) : FileMessagesFromDevice()

        /** Transfer cancelled. */
        @Serializable
        data class Cancel(
            val type: String = "cancel"
        ) : FileMessagesFromDevice()

        /** Storage usage query response. */
        @Serializable
        data class Usage(
            val type: String = "usage",
            val usage: Long
        ) : FileMessagesFromDevice()
    }

    @Serializable
    private sealed class FileMessagesToSend {
        /** Query storage usage. */
        @Serializable
        data class GetUsage(
            val tag: String = "file",
            val stat: String = "getUsage"
        ) : FileMessagesToSend()

        /** Start a transfer. */
        @Serializable
        data class StartTransfer(
            val tag: String = "file",
            val stat: String = "startTransfer",
            val filename: String,
            val total: Int,              // index of the last chunk (size - 1)
            val chunkSize: Int
        ) : FileMessagesToSend()

        /** A data chunk. */
        @Serializable
        data class DataChunk(
            val tag: String = "file",
            val stat: String = "d",
            val setCount: Int?,          // optional: reset the watch's expected index (resume)
            val count: Int,              // current chunk index
            val data: String             // chunk text content
        ) : FileMessagesToSend()

        /** Cancel the transfer. */
        @Serializable
        data class Cancel(
            val tag: String = "file",
            val stat: String = "cancel"
        ) : FileMessagesToSend()
    }

    /**
     * Split a string into pieces whose encoding in [charset] is at most
     * [byteSize] bytes long.
     */
    private fun String.chunkedByBytes(byteSize: Int, charset: Charset = Charsets.UTF_16LE): List<String> {
        val byteArray = this.toByteArray(charset)
        val chunks = mutableListOf<String>()
        var index = 0
        while (index < byteArray.size) {
            val end = (index + byteSize).coerceAtMost(byteArray.size)
            chunks.add(String(byteArray.copyOfRange(index, end), charset))
            index = end
        }
        return chunks
    }
}
