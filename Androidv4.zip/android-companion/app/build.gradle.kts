import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    kotlin("plugin.serialization")
}

android {
    namespace = "com.application.examreader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.application.examreader"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // ------------------------------------------------------------------
    // Xiaomi XMS Wearable SDK (local AAR).
    // Place the SDK AAR at: app/libs/xms-wearable-lib_1.4_release.aar
    // It is NOT shipped here because it is a licensed Xiaomi redistributable.
    // ------------------------------------------------------------------
    val wearableAar = File(projectDir, "libs/xms-wearable-lib_1.4_release.aar")
    if (wearableAar.exists()) {
        implementation(files(wearableAar))
    } else {
        throw GradleException(
            "Missing XMS Wearable SDK AAR.\n" +
                    "Please place the file at: app/libs/xms-wearable-lib_1.4_release.aar\n" +
                    "Obtain it from the Xiaomi Vela / XMS Wearable SDK distribution."
        )
    }

    // Kotlin serialization + charset detection
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("com.github.albfernandez:juniversalchardet:2.4.0")

    // AndroidX core
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.loader:loader:1.1.0")

    // Jetpack Compose
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Material Components (for the XML splash theme Theme.Material3.*)
    implementation("com.google.android.material:material:1.12.0")

    // Unit tests
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.12.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
