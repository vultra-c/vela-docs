# 考点阅读器同步器 (ExamReader Companion)

Android companion app that pairs with the **ExamReader Vela** quick app
(package `com.application.examreader`) running on a **Xiaomi Band 9 Pro**.
It sends `.txt` files to the watch over Bluetooth using Xiaomi's **XMS
Wearable SDK** interconnect protocol.

The protocol and architecture are adapted from the MeowMeow e-book
(`com.bandbbs.ebook`) companion app, using the same SDK and the same
handshake / file-transfer protocol, but retargeted to the ExamReader package
name and the watch app's `/pages/transfer` page.

> The watch-side implementation lives in
> `examreader-v4.0/src/utils/interconnect-transfer.js` and the transfer page
> in `examreader-v4.0/src/pages/transfer/transfer.ux`. This Android app is the
> phone side of that link.

---

## How it works

1. **Connect** — `Interconn` finds the first connected wearable node through
   `NodeApi`, requests the `DEVICE_MANAGER` permission via `AuthApi`, and
   launches the watch app's **`/pages/transfer`** page with `NodeApi.launchWearApp`.
2. **Handshake** — `InterHandshake` performs a 3-way handshake
   (`tag:"__hs__"`, count `0 -> 1 -> 2`) with a 3000 ms timeout and a watchdog
   timer that resets on every incoming message. The first `sendMessage` blocks
   until the handshake completes.
3. **Transfer** — `InterconnetFile` auto-detects the file charset
   (`UniversalDetector`), re-chunks the text by **UTF-16LE bytes** in 20 KB
   pieces and streams them with ACK flow control:
   - phone sends `startTransfer` -> watch answers `ready` (with optional
     `length` for resume)
   - phone sends `d` chunks -> watch answers `next` / `error` / `success`
   - resume: if the watch reports `found:true` with a `length`, transfer
     resumes from `length / FILE_SIZE`

All payloads are JSON strings routed by their `tag` field (`__hs__` or `file`).

---

## Project layout

```
android-companion/
├── settings.gradle.kts
├── build.gradle.kts                 # project-level plugins
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── README.md
└── app/
    ├── build.gradle.kts             # applicationId = com.application.examreader
    ├── proguard-rules.pro
    ├── libs/
    │   └── PLACE_AAR_HERE.txt       # put xms-wearable-lib_1.4_release.aar here
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/application/examreader/
        │   ├── App.kt               # Application, holds shared InterHandshake
        │   ├── MainActivity.kt      # connect + file pick + push
        │   ├── PushActivity.kt      # transfer progress UI
        │   ├── logic/
        │   │   ├── Interconn.kt     # NodeApi/AuthApi/MessageApi wrapper
        │   │   ├── InterHandshake.kt# 3-way handshake + watchdog
        │   │   └── InterconnetFile.kt # file transfer protocol
        │   ├── utils/
        │   │   └── FileUtils.kt     # uriToFile, bytesToReadable
        │   └── ui/
        │       ├── theme/Theme.kt
        │       └── components/Components.kt
        └── res/...
```

---

## Prerequisites

- **JDK 17** (required by AGP 8.7 / Gradle 8.11).
- **Android SDK** with **Platform 35** (Android 15) and Build-Tools 35.x.
- **Android Studio** (Koala/Ladybug or newer) **or** the Gradle CLI.
- **Mi Fitness (小米运动健康)** installed and paired with the Xiaomi Band 9 Pro
  on the phone — the XMS Wearable SDK routes through it.
- The **XMS Wearable SDK AAR**, `xms-wearable-lib_1.4_release.aar` (the same
  artifact the MeowMeow e-book companion uses). It is a licensed Xiaomi
  redistributable and is **not** included here.

## Add the SDK AAR (required)

Copy the AAR to:

```
app/libs/xms-wearable-lib_1.4_release.aar
```

Without this file the build fails by design
(`app/build.gradle.kts` throws a `GradleException` if the AAR is missing),
because the connection layer depends on `com.xiaomi.xms.wearable.*`.

## Build

The Gradle wrapper jar is intentionally not committed. Generate it once with a
system Gradle (>= 8.11) or let Android Studio create it on first sync:

```bash
# from android-companion/
gradle wrapper --gradle-version 8.11.1     # creates gradlew + wrapper jar
./gradlew assembleDebug
```

Or, in Android Studio: **File > Open** this folder, let it sync, then
**Run > Run 'app'**.

The debug APK is output to `app/build/outputs/apk/debug/`.

## Install & use

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

1. Open **考点阅读器同步器** on the phone.
2. The device card connects to the band, checks that the ExamReader Vela app
   is installed, and opens its **/pages/transfer** page.
3. Tap the file card and pick a `.txt` file.
4. Tap **推送** to push it. The push screen shows progress, chunk preview and
   speed; tap **取消** to abort (or **完成** when done).

On the watch, the received file is stored under
`internal://files/received/` and registered in the ExamReader library.

---

## Configuration notes

- **`applicationId` / namespace**: `com.application.examreader` — matches the
  watch app's `package` in `manifest.json`. The phone companion and the Vela
  app intentionally share the same application id so the XMS interconnect
  links them.
- **Transfer page**: `Interconn.openApp()` launches **`/pages/transfer`**
  (the Vela router route defined in `examreader-v4.0/src/manifest.json`), not
  `/pages/push`.
- **Chunk size**: `FILE_SIZE = 1024 * 20` (20 KB), chunked by UTF-16LE bytes,
  matching the watch-side `interconnect-transfer.js`.
- **Minify** is disabled in `release` for build safety; `proguard-rules.pro`
  keeps the serialization models and the SDK should you enable it.

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| "未找到设备！" | Mi Fitness not running / band not paired. Keep Mi Fitness alive in the background. |
| "考点阅读器未安装" | The ExamReader Vela app is not installed on the band. Install it first. |
| "握手超时" | The watch transfer page did not open or respond. Reopen the app and retry; ensure the band screen is on the transfer page. |
| Build fails on missing AAR | Place `xms-wearable-lib_1.4_release.aar` in `app/libs/`. |
| `BLUETOOTH_SCAN`/`BLUETOOTH_CONNECT` denied | Grant the runtime Bluetooth permission shown on first launch (Android 12+). |
