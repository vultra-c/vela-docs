/**
 * ⚠️ 本文件由 scripts/gen-topics.js 自动生成，请勿手动编辑！
 * 仅包含结构（文件夹名/文章标题），不包含正文内容。
 * 正文内容在 src/common/content/ 下的 .txt 资源文件中，运行时按需读取。
 */

export const DATA = [
  {
    "name": "00-总览",
    "children": [
      {
        "title": "版本说明",
        "author": ""
      }
    ]
  },
  {
    "name": "01-七年级",
    "children": [
      {
        "name": "01-语文",
        "children": [
          {
            "title": "七年级上册语文知识点",
            "author": ""
          },
          {
            "title": "七年级下册语文知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "02-数学",
        "children": [
          {
            "title": "七年级上册数学知识点",
            "author": ""
          },
          {
            "title": "七年级下册数学知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "03-英语",
        "children": [
          {
            "title": "七年级上册英语知识点",
            "author": ""
          },
          {
            "title": "七年级下册英语知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "04-历史",
        "children": [
          {
            "title": "七年级上册历史知识点",
            "author": ""
          },
          {
            "title": "七年级下册历史知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "05-道法",
        "children": [
          {
            "title": "七年级上册道法知识点",
            "author": ""
          },
          {
            "title": "七年级下册道法知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "06-地理",
        "children": [
          {
            "title": "七年级上册地理知识点",
            "author": ""
          },
          {
            "title": "七年级下册地理知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "07-生物",
        "children": [
          {
            "title": "七年级上册生物知识点",
            "author": ""
          },
          {
            "title": "七年级下册生物知识点",
            "author": ""
          }
        ]
      }
    ]
  },
  {
    "name": "02-八年级",
    "children": [
      {
        "name": "01-语文",
        "children": [
          {
            "title": "八年级上册语文知识点",
            "author": ""
          },
          {
            "title": "八年级下册语文知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "02-数学",
        "children": [
          {
            "title": "八年级上册数学知识点",
            "author": ""
          },
          {
            "title": "八年级下册数学知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "03-英语",
        "children": [
          {
            "title": "八年级上册英语知识点",
            "author": ""
          },
          {
            "title": "八年级下册英语知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "04-历史",
        "children": [
          {
            "title": "八年级上册历史知识点",
            "author": ""
          },
          {
            "title": "八年级下册历史知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "05-道法",
        "children": [
          {
            "title": "八年级上册道法知识点",
            "author": ""
          },
          {
            "title": "八年级下册道法知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "06-地理",
        "children": [
          {
            "title": "八年级上册地理知识点",
            "author": ""
          },
          {
            "title": "八年级下册地理知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "07-生物",
        "children": [
          {
            "title": "八年级上册生物知识点",
            "author": ""
          },
          {
            "title": "八年级下册生物知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "08-物理",
        "children": [
          {
            "title": "八年级上册物理知识点",
            "author": ""
          },
          {
            "title": "八年级下册物理知识点",
            "author": ""
          }
        ]
      }
    ]
  },
  {
    "name": "03-九年级",
    "children": [
      {
        "name": "01-语文",
        "children": [
          {
            "title": "九年级上册语文知识点",
            "author": ""
          },
          {
            "title": "九年级下册语文知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "02-数学",
        "children": [
          {
            "title": "九年级上册数学知识点",
            "author": ""
          },
          {
            "title": "九年级下册数学知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "03-英语",
        "children": [
          {
            "title": "九年级上册英语知识点",
            "author": ""
          },
          {
            "title": "九年级下册英语知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "04-历史",
        "children": [
          {
            "title": "九年级上册历史知识点",
            "author": ""
          },
          {
            "title": "九年级下册历史知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "05-道法",
        "children": [
          {
            "title": "九年级上册道法知识点",
            "author": ""
          },
          {
            "title": "九年级下册道法知识点",
            "author": ""
          }
        ]
      },
      {
        "name": "06-化学",
        "children": [
          {
            "title": "九年级上册化学知识点",
            "author": ""
          },
          {
            "title": "九年级下册化学知识点",
            "author": ""
          }
        ]
      }
    ]
  },
  {
    "name": "99-附录",
    "children": [
      {
        "name": "参考资料",
        "children": [
          {
            "title": "来源清单",
            "author": ""
          }
        ]
      },
      {
        "name": "知识点索引",
        "children": [
          {
            "title": "全量知识点索引",
            "author": ""
          }
        ]
      }
    ]
  },
  {
    "title": "README",
    "author": ""
  }
]

export function getNode(path) {
  let node = { name: '分类', children: DATA }
  if (!path) return node
  const parts = path.split('-')
  for (let i = 0; i < parts.length; i++) {
    const idx = parseInt(parts[i])
    if (!node || !node.children || !node.children[idx]) return null
    node = node.children[idx]
  }
  return node
}
